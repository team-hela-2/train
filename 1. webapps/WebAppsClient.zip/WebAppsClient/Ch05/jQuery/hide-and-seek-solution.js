
function init() {
    $('.hide').click(function () {
        $('div').hide();
    });
    $('.show').click(function () {
        $('div').show();
    });

}

$(document).ready(function () {
    init()
});
