let MathUtils = require('../MathUtils');

// This is our test suite
describe('MathUtils', function () {
    let calc;

    // This will be called before running each spec
    beforeEach(function () {
        calc = new MathUtils();
    });

    // This will be called after running each spec
    // Setting calc to null is not really necessary, but shown as an example
    afterEach(function () {
        calc = null;
    });

    // describes may be nested to group related tests together
    describe('when calc is used to perform basic math operations', function () {

        // Spec for sum operation
        it('should be able to calculate sum of 3 and 5', function () {
            expect(calc.sum(3, 5)).toEqual(8);
        });

        // Spec for multiply operation
        it('should be able to multiply 3 and 5', function () {
            expect(calc.multiply(3, 5)).toEqual(15);
        });

    });

    // describes may be nested to group related tests together
    describe('when calc is used to calculate factorials', function () {
        // TODO: write a test for function factorial using the number 9

         
        // TODO: write a test for function factorial using the number -7
        // You expect this spec to throw an error
        // HINT: you will need toThrowError instead of toEqual

    });

});
