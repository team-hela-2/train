console.log('This project doesn\'t do anything: try typing npm test');
