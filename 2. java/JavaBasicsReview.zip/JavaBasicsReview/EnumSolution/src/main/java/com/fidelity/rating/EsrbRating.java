package com.fidelity.rating;

public enum EsrbRating {
	EVERYONE("E", "Everyone") {
		@Override
		public boolean isAppropriate(int age) {
			return true;
		}
	},
	EVERYONE_10_PLUS("E10+", "Everyone 10+") {
		@Override
		public boolean isAppropriate(int age) {
			return age >= 10;
		}		
	},
	TEEN("T", "Teen") {
		@Override
		public boolean isAppropriate(int age) {
			return age >= 13;
		}		
	},
	MATURE("M", "Mature") {
		@Override
		public boolean isAppropriate(int age) {
			return age >= 17;
		}		
	},
	ADULTS_ONLY("AO", "Adults Only") {
		@Override
		public boolean isAppropriate(int age) {
			return age >= 18;
		}		
	},
	RATING_PENDING("RP", "Rating Pending");

	private String code;
	private String description;

	EsrbRating(String code, String description) {
		this.code = code;
		this.description = description;
	}
	
	public String getCode() {
		return code;
	}

	public String getDescription() {
		return description;
	}

	public boolean isAppropriate(int age) {
		return false;
	}

}
