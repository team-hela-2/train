package com.fidelity.model;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;

import com.fidelity.utils.Generated;

/**
 * SavingsAccount defines the properties of a saving account.
 * 
 * @author ROI Instructor Team
 */
public class SavingsAccount extends Account {
	private static final BigDecimal INTEREST_RATE = new BigDecimal(1.03);
	private final LocalDate startDate;

	public SavingsAccount(String accountNumber, BigDecimal balance, LocalDate startDate) {
		super(accountNumber, balance);
		if (startDate == null) {
			throw new IllegalArgumentException("start date can't be null");
		}
		this.startDate = startDate;
	}

	/**
	 * Calculate the saving account balance. If the account was started more
	 * than one year ago, interest is added to the initial balance.
	 */
	@Override
	public BigDecimal calculateCurrentBalance() {
		// If account is more than one year old, calculate interest for
		// one year only, whatever the age of the account.
		// We also assume a fixed interest rate of 3%
		BigDecimal value = getBalance();
		if (LocalDate.now().isAfter(startDate.plusYears(1))) {
			value = value.multiply(INTEREST_RATE);
		}
		BigDecimal balance = value.setScale(2, RoundingMode.HALF_EVEN );
		return balance;
	}

	@Generated
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((startDate == null) ? 0 : startDate.hashCode());
		return result;
	}

	@Generated
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		SavingsAccount other = (SavingsAccount) obj;
		if (startDate == null) {
			if (other.startDate != null)
				return false;
		} else if (!startDate.equals(other.startDate))
			return false;
		return true;
	}

	@Generated
	@Override
	public String toString() {
		return "SavingsAccount [startDate=" + startDate + ", getGrossBalance()=" + getBalance() + ", getAccountNumber()="
				+ getAccountNumber() + "]";
	}

}
