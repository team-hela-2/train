package com.fidelity.model;

import static org.junit.jupiter.api.Assertions.*;

import java.math.BigDecimal;
import java.time.LocalDate;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * GicAccountTest defines unit tests for GicAccount.
 * 
 * @author ROI Instructor Team
 */
class GicAccountTest {
	private static final BigDecimal ONE_HUNDRED = new BigDecimal(100);

	private GicAccount account;
	
	@BeforeEach
	void setUp() throws Exception {
	}

	@Test
	void createGicAccount_Success( ) {
		String accountNumber = "abc123";
		account = new GicAccount(accountNumber, ONE_HUNDRED, LocalDate.now(), BigDecimal.TEN, 12);
		
		String result = account.getAccountNumber();
		
		assertEquals(accountNumber, result);
	}

	@Test
	void createGicAccount_NullStartDate_ThrowsException( ) {
		assertThrows(IllegalArgumentException.class, () -> {
			new GicAccount("gic123", ONE_HUNDRED, null, BigDecimal.TEN, 12);
		});
	}

	@Test
	void createGicAccount_NullFee_ThrowsException( ) {
		assertThrows(IllegalArgumentException.class, () -> {
			new GicAccount("gic123", ONE_HUNDRED, LocalDate.now(), null, 12);
		});
	}

	@Test
	void createGicAccount_NegativeTerm_ThrowsException( ) {
		assertThrows(IllegalArgumentException.class, () -> {
			new GicAccount("gic123", ONE_HUNDRED, LocalDate.now(), null, -12);
		});
	}

	@Test
	void getBalance_InitialBalanceLessThanFee() {
		account = new GicAccount("gic123", BigDecimal.ZERO, LocalDate.now(), BigDecimal.TEN, 12);
		
		BigDecimal balance = account.calculateCurrentBalance();
		
		assertEquals(Account.ZERO_BALANCE, balance);
	}

	@Test
	void getBalance_AgeLessThanOneYear_NoInterest() {
		account = new GicAccount("gic123", ONE_HUNDRED, LocalDate.now(), BigDecimal.TEN, 12);
		
		BigDecimal balance = account.calculateCurrentBalance();
		
		assertEquals(new BigDecimal("90.00"), balance);
	}


	@Test
	void getBalance_AgeMotrThanOneYear_AccruesInterest() {
		account = new GicAccount("gic123", ONE_HUNDRED, LocalDate.now().minusDays(367), BigDecimal.TEN, 12);
		
		BigDecimal balance = account.calculateCurrentBalance();
		
		assertEquals(new BigDecimal("95.00"), balance);
	}

}
