package com.fidelity.encryption;

import com.fidelity.cipher.BifidAlgorithmImpl;
import com.fidelity.cipher.CipherAlgorithm;

public class FileEncrypterBifid extends FileEncrypter {

	public FileEncrypterBifid(String key) {
		super(key);
	}

	@Override
	protected CipherAlgorithm getAlgorithm(String key) {
		CipherAlgorithm ca = new BifidAlgorithmImpl();
		ca.setKey(key);
		return ca;
	}

}
