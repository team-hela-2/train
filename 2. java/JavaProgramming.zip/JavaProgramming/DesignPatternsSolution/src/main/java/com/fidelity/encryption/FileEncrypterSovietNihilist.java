package com.fidelity.encryption;

import com.fidelity.cipher.CipherAlgorithm;
import com.fidelity.cipher.SovietNihilistAlgorithmImpl;

public class FileEncrypterSovietNihilist extends FileEncrypter {

	public FileEncrypterSovietNihilist(String key) {
		super(key);
	}

	@Override
	protected CipherAlgorithm getAlgorithm(String key) {
		CipherAlgorithm ca = new SovietNihilistAlgorithmImpl();
		ca.setKey(key);
		return ca;
	}

}
