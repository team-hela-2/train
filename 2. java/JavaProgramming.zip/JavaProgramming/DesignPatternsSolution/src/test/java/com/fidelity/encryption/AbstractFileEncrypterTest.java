package com.fidelity.encryption;

import static org.junit.jupiter.api.Assertions.*;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/*
 * Abstract superclass for all FileEncrypter tests. Since each test class is essentially the
 * same, this approach reduces duplicated code. It is equivalent of writing the test out in
 * full in the subclass.
 * 
 * Note that it is not necessary for this test class to contain all the tests of the cipher
 * algorithm since it is *not* testing whether the algorithm gives the right results, only
 * whether the file is correctly encrypted or decrypted.
 */
abstract class AbstractFileEncrypterTest {

	private FileEncrypter fe;

	File testInFile;
	File testOutFile;
	
	// Abstract methods used to set all the things that differ between different test classes
	abstract FileEncrypter getFileEncrypter();
	abstract String getPlaintext();
	abstract String getCiphertext();
	
	/*
	 * A word about temporary files. There are clearly situations in which this approach could leave
	 * temporary files in existence. In JUnit 4, there was a Rule that provided a more water-tight
	 * method for managing temporary files, but that has not yet been ported to JUnit 5. You could 
	 * create a JUnit Extension (the replacement for Rules) that does the same, but I decided that
	 * was overkill for this test.
	 */
	@BeforeEach
	void setUp() throws IOException {
		fe = getFileEncrypter();		

		testInFile = File.createTempFile("tst", ".txt");	
		testOutFile = File.createTempFile("tst", ".txt");	
		// If the test fails badly, this should cause the files to be deleted eventually
		testInFile.deleteOnExit();
		testOutFile.deleteOnExit();
	}

	@AfterEach
	void tearDown() {
		// Note that while deleteOnExit() is a backup, we don't want to rely on it
		testInFile.delete();
		testOutFile.delete();
	}

	@Test
	void testEncryptFile() throws IOException {
		FileWriter w = new FileWriter(testInFile);
		w.write(getPlaintext());
		w.close();

		fe.encryptFile(testInFile.getAbsolutePath(), testOutFile.getAbsolutePath());

		List<String> lines = Files.readAllLines(testOutFile.toPath());
		
		assertEquals(1, lines.size());
		assertEquals(getCiphertext(), lines.get(0));
	}

	@Test
	void testDecryptFile() throws IOException {
		FileWriter w = new FileWriter(testInFile);
		w.write(getCiphertext());
		w.close();

		fe.decryptFile(testInFile.getAbsolutePath(), testOutFile.getAbsolutePath());

		List<String> lines = Files.readAllLines(testOutFile.toPath());
		
		assertEquals(1, lines.size());
		assertEquals(getPlaintext(), lines.get(0));
	}
}
