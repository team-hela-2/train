package com.fidelity.encryption;

class FileEncrypterFourSquareTest extends AbstractFileEncrypterTest {

	@Override
	FileEncrypter getFileEncrypter() {
		return new FileEncrypterFourSquare("ThE aNsWeR iS 42,RoYgBiV");
	}

	@Override
	String getPlaintext() {
		return "Hello World";
	}

	@Override
	String getCiphertext() {
		return "5ckkkgPlkrjt";
	}

}
