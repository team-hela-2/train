package com.fidelity.primitives;

import java.util.Iterator;
import java.util.List;

public class PrimitiveList {

	// This approach iterates through the list backwards, meaning array indexes are preserved
	public void removeNegatives(List<Integer> values) {
		for (int i = values.size() - 1; i >= 0; i--) {
			if (values.get(i) < 0) {
				values.remove(i);
			}
		}
	}

	/*
	 * This approach is the *only* completely safe way to remove an item while iterating in a
	 * multi-threaded environment
	 */
	public void removeNegativesByIterator(List<Integer> values) {
		Iterator<Integer> it = values.iterator();
	    while (it.hasNext()) {
	        Integer i = it.next();
	        if (i < 0) {
	        	it.remove();
	        }
	    }
	}
}
