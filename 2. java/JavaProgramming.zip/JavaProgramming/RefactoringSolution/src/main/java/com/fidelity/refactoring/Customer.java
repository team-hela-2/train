package com.fidelity.refactoring;

import java.util.ArrayList;
import java.util.List;

public class Customer {
	
    private String name;
    private List<Rental> rentals;

    public Customer (String name) {
        this.name = name;
        rentals = new ArrayList<>();
    }

    public String getName () {
        return name;
    }

    public void addRental (Rental rental) {
        rentals.add(rental);
    }

    public String statement () {
        double totalAmount = 0;
        int frequentRenterPoints = 0;
        String result = "Rental record for " + getName() + "\n";

        for (Rental rental : rentals) {
            double amount = rental.getCharge();
            
            // add frequent renter points
            frequentRenterPoints += rental.getFrequentRenterPoints();

            // show figures for this rental
            result += "\t" + rental.getMovie().getTitle() + "\t" + amount + "\n";
            totalAmount += amount;
        }

        result += "Amount owed is " + totalAmount + "\n";
        result += "You earned " + frequentRenterPoints + " frequent renter points";
        
        return result;
    }
}
