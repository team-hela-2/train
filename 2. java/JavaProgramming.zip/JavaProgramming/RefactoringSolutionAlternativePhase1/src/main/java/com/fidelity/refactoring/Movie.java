package com.fidelity.refactoring;

/**
 * Now Movie is abstract.
 */
public abstract class Movie {
	
    private String title;
    /** Notice we don't need a rental type field */

    public Movie (String title) {
        this.title = title;
    }

    public String getTitle () {
        return title;
    }

    /** 
     * getRentalAmount() is abstract: subclasses must implement it.
     */
    public abstract double getRentalAmount(int daysRented);
    
    /** 
     * getFrequentRenterBonusPoints() is concrete: subclasses
     * may inherit this implementation, or they may override it
     * with a different implementation.
     */
    public double getFrequentRenterPoints(int daysRented) {
    	return 0;
    }
}
