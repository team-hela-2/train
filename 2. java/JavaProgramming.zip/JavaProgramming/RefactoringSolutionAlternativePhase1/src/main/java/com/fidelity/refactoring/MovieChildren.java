package com.fidelity.refactoring;

/**
 * MovieChildren extends the abstract class Movie.
 */
public class MovieChildren extends Movie {
	
    public MovieChildren (String title) {
        super(title);
    }

	/**
	 * MovieChildren must implement getRentalAmount()
	 */
    public double getRentalAmount(int daysRented) {
        double amount = 1.5;
        if (daysRented > 3) {
            amount += (daysRented - 3) * 1.5;
        }
        return amount;
    }

	/** 
	 * MovieChildren doesn't implement getFrequentRenterBonusPoints(),
	 * so it inherits its superclass's implementation.
	 */
}
