package com.fidelity.refactoring;

/**
 * MovieNewRelease extends the abstract class Movie.
 */
public class MovieNewRelease extends Movie {
	
    public MovieNewRelease (String title) {
        super(title);
    }

	/**
	 * MovieNewRelease must implement getRentalAmount()
	 */
    public double getRentalAmount(int daysRented) {
        return daysRented * 3;
    }
    
	/** 
	 * RentalNewRelease needs to customize getFrequentRenterBonusPoints(),
	 * so it overrides the superclass's implementation.
	 */
    public double getFrequentRenterPoints(int daysRented) {
    	return (daysRented > 1) ? 1 : 0;
    }
}
