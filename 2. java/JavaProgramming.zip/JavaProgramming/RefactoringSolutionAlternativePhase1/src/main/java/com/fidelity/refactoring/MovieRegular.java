package com.fidelity.refactoring;

/**
 * MovieRegular extends the abstract class Movie.
 */
public class MovieRegular extends Movie {
	
    public MovieRegular (String title) {
        super(title);
    }

	/**
	 * MovieRegular must implement getRentalAmount()
	 */
    public double getRentalAmount(int daysRented) {
        double amount = 2;
        if (daysRented > 2) {
            amount += (daysRented - 2) * 1.5;
        }
        return amount;
    }

	/** 
	 * MovieRegular doesn't implement getFrequentRenterBonusPoints(),
	 * so it inherits its superclass's implementation.
	 */
}
