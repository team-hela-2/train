# Exercise 10.1: Refactoring Code - Alternative Solution

The first solution to this exercise uses the [Strategy design pattern]
(https://en.wikipedia.org/wiki/Strategy_pattern)
* The PriceCode class defines Strategies to calculate rental charge and 
  frequent renter points
* But it's implemented as an enum, which makes it hard to understand

In addition, the first solution has design deficiencies and anti-patterns:
* Customer.statement() determines the charge for a rental 
    - This results in an anemic data model: all business logic is in one 
      Supervisor class
        - See https://martinfowler.com/bliki/AnemicDomainModel.html
    - Instead, each domain class should implement its own business logic
        - The calculation should be done by each type of Rental/Movie
* Customer.statement(): Contains conditional code to test object type
    - Should be replaced by inheritance and polymorphism
* Movie types are defined in Movie as static int fields
    - Type fields should be replaced by polymorphic subclasses
    - If you need to define constants, use an enum instead of static fields
* Rental fee calculation is in Movie.getCharge() but it should be in Rental

## Refactoring Strategy

We'll implement an alternative solution that is cleaner and easier to understand.

The required changes are too extensive to be done in one pass, so we'll
break it into two phases: 
- Phase 1: Remove conditional code
- Phase 2: Move rental fee calculation into Rental class

### Phase 1 tasks:
1. Create Movie unit tests that validate new, non-existent methods getRentalAmount() 
   and getFrequentRenterPoints()
2. Move code that checks priceCode from client code to new methods in Movie
3. Verify unit tests still pass
4. Modify unit tests to instantiate new (non-existent subclasses), verify tests fail
5. Make Movie abstract, make getRentalAmount() abstract, create 3 subclasses of Movie
6. Verify unit tests pass

   Note: Resist the temptation to replace Movie price codes with isNewRelease() 
   and isChildren(): what would happen when you need to create new price codes 
   (Dvd, Streaming, ...)?
      You'd need to modify existing code: violates Open/Closed principle

### Phase 2 tasks:
1. Move getRentalAmount() and getFrequentRenterPoints() to Rental, where they belong
2. Verify unit tests still pass
