package com.fidelity.refactoring;

import java.util.ArrayList;
import java.util.List;

public class Customer {
	
    private String name;
    private List<Rental> rentals;

    public Customer (String name) {
        this.name = name;
        rentals = new ArrayList<>();
    }

    public String getName () {
        return name;
    }

    public void addRental (Rental rental) {
        rentals.add(rental);
    }

    public String statement () {
        double totalAmount = 0;
        int frequentRenterPoints = 0;
        String result = "Rental record for " + getName() + "\n";

        for (Rental rental : rentals) {
        	// Java will polymorphically choose the correct getRentalAmount()
        	// method to call, based on the runtime type of the Rental
            double amount = rental.getRentalAmount();
            
            // add frequent renter points with another polymorphic call
            frequentRenterPoints += 1 + rental.getFrequentRenterBonusPoints();
            
            // show figures for this rental
            result += "\t" + rental.getMovie().getTitle() + "\t" + amount + "\n";
            totalAmount += amount;
        }

        result += "Amount owed is " + totalAmount + "\n";
        result += "You earned " + frequentRenterPoints + " frequent renter points";
        
        return result;
    }
}
