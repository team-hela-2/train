package com.fidelity.refactoring;

/**
 * Now Rental is abstract
 */
public abstract class Rental {
	
    private Movie movie;
    private int daysRented;
    /** Notice we don't need a rental type field */

    public Rental (Movie movie, int daysRented) {
        this.movie = movie;
        this.daysRented = daysRented;
    }

    public Movie getMovie () {
        return movie;
    }

    public int getDaysRented () {
        return daysRented;
    }

    /** 
     * getRentalAmount() is abstract: subclasses must implement it
     */
    public abstract double getRentalAmount();
    
    /** 
     * getFrequentRenterBonusPoints() is concrete: subclasses
     * may inherit this implementation, or they may override it
     * with a different implementation.
     */
    public int getFrequentRenterBonusPoints() {
    	return 0;
    }
}
