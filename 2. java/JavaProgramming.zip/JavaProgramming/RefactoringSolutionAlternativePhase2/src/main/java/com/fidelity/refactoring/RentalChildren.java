package com.fidelity.refactoring;

public class RentalChildren extends Rental {

	public RentalChildren(Movie movie, int daysRented) {
		super(movie, daysRented);
	}
	
	/**
	 * RentalChildren must implement getRentalAmount()
	 */
	@Override
	public double getRentalAmount() {
		double amount = 1.5;
        if (getDaysRented() > 3) {
            amount += (getDaysRented() - 3) * 1.5;
        }
		return amount;
	}

	/** 
	 * RentalChildren doesn't implement getFrequentRenterBonusPoints(),
	 * so it inherits its superclass's implementation.
	 */
}
