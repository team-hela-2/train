package com.fidelity.refactoring;

public class RentalNewRelease extends Rental {

	public RentalNewRelease(Movie movie, int daysRented) {
		super(movie, daysRented);
	}
	
	/**
	 * RentalNewRelease must implement getRentalAmount()
	 */
	@Override
	public double getRentalAmount() {
		return getDaysRented() * 3;
	}

	/** 
	 * RentalNewRelease needs to customize getFrequentRenterBonusPoints(),
	 * so it overrides the superclass's implementation.
	 */
	@Override
	public int getFrequentRenterBonusPoints() {
    	return getDaysRented() > 1 ? 1 : 0;
    }
}
