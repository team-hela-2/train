package com.fidelity.refactoring;

public class RentalRegular extends Rental {

	public RentalRegular(Movie movie, int daysRented) {
		super(movie, daysRented);
	}
	
	/**
	 * RentalRegular must implement getRentalAmount()
	 */
	@Override
	public double getRentalAmount() {
		double amount = 2;
		if (getDaysRented() > 2) {
            amount += (getDaysRented() - 2) * 1.5;
        }
		return amount;
	}

	/** 
	 * RentalRegular doesn't implement getFrequentRenterBonusPoints(),
	 * so it inherits its superclass's implementation.
	 */
 }
