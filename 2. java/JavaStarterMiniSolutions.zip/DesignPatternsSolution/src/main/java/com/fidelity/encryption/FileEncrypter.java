package com.fidelity.encryption;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.function.Function;
import java.util.stream.Stream;

import com.fidelity.cipher.CipherAlgorithm;

public abstract class FileEncrypter {
	private CipherAlgorithm ca;

	public FileEncrypter(String key) {
		super();
		this.ca = getAlgorithm(key);
	}

	protected abstract CipherAlgorithm getAlgorithm(String key);
	
	/*
	 * Don't worry about what these methods are actually doing, this is just a fancy way of
	 * reducing duplicate code by passing a function reference into a common method.
	 */
	public void encryptFile(String inFile, String outFile) throws IOException {
		convertFile(inFile, outFile, ca::encrypt);
	}
	
	public void decryptFile(String inFile, String outFile) throws IOException {
		convertFile(inFile, outFile, ca::decrypt);
	}
	
	private void convertFile(String inFile, String outFile, Function<String, String> operation) throws IOException {
		try (Stream<String> stream = Files.lines(Paths.get(inFile));
			PrintWriter pw = new PrintWriter(Files.newBufferedWriter(Paths.get(outFile)))) {
			stream.map(operation)
				.forEach(pw::println);
		}
	}
	
}
