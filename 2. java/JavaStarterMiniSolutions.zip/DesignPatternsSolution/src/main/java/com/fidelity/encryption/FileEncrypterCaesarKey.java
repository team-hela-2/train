package com.fidelity.encryption;

import com.fidelity.cipher.CaesarKeyAlgorithmImpl;
import com.fidelity.cipher.CipherAlgorithm;

public class FileEncrypterCaesarKey extends FileEncrypter {

	public FileEncrypterCaesarKey(String key) {
		super(key);
	}

	@Override
	protected CipherAlgorithm getAlgorithm(String key) {
		CipherAlgorithm ca = new CaesarKeyAlgorithmImpl();
		ca.setKey(key);
		return ca;
	}

}
