package com.fidelity.encryption;

import com.fidelity.cipher.CipherAlgorithm;
import com.fidelity.cipher.FourSquareAlgorithmImpl;

public class FileEncrypterFourSquare extends FileEncrypter {

	public FileEncrypterFourSquare(String key) {
		super(key);
	}

	@Override
	protected CipherAlgorithm getAlgorithm(String key) {
		CipherAlgorithm ca = new FourSquareAlgorithmImpl();
		ca.setKey(key);
		return ca;
	}

}
