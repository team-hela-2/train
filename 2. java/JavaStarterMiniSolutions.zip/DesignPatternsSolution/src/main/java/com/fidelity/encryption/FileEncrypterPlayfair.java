package com.fidelity.encryption;

import com.fidelity.cipher.CipherAlgorithm;
import com.fidelity.cipher.PlayfairAlgorithmImpl;

public class FileEncrypterPlayfair extends FileEncrypter {

	public FileEncrypterPlayfair(String key) {
		super(key);
	}

	@Override
	protected CipherAlgorithm getAlgorithm(String key) {
		CipherAlgorithm ca = new PlayfairAlgorithmImpl();
		ca.setKey(key);
		return ca;
	}

}
