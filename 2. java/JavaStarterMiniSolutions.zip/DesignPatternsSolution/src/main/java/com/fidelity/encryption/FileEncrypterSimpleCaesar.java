package com.fidelity.encryption;

import com.fidelity.cipher.CipherAlgorithm;
import com.fidelity.cipher.SimpleCaesarAlgorithmImpl;

public class FileEncrypterSimpleCaesar extends FileEncrypter {

	public FileEncrypterSimpleCaesar(String key) {
		super(key);
	}

	@Override
	protected CipherAlgorithm getAlgorithm(String key) {
		CipherAlgorithm ca = new SimpleCaesarAlgorithmImpl();
		ca.setKey(key);
		return ca;
	}

}
