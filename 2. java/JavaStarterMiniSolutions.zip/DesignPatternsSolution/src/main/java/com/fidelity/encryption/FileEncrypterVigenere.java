package com.fidelity.encryption;

import com.fidelity.cipher.CipherAlgorithm;
import com.fidelity.cipher.VigenereAlgorithmImpl;

public class FileEncrypterVigenere extends FileEncrypter {

	public FileEncrypterVigenere(String key) {
		super(key);
	}

	@Override
	protected CipherAlgorithm getAlgorithm(String key) {
		CipherAlgorithm ca = new VigenereAlgorithmImpl();
		ca.setKey(key);
		return ca;
	}

}
