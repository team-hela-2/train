package com.fidelity.encryption;

class FileEncrypterBifidTest extends AbstractFileEncrypterTest {

	@Override
	FileEncrypter getFileEncrypter() {
		return new FileEncrypterBifid("ThE aNsWeR iS 42,7");
	}

	@Override
	String getPlaintext() {
		return "Hello World";
	}

	@Override
	String getCiphertext() {
		return "Dqkah4KqpX4";
	}

}
