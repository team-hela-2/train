package com.fidelity.encryption;

import static org.junit.jupiter.api.Assertions.*;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/*
 * Note that it is not necessary for this test class to contain all the tests of the cipher
 * algorithm since it is *not* testing whether the algorithm gives the right results, only
 * whether the file is correctly encrypted or decrypted.
 * 
 * Each test class is almost the same. One way to avoid duplicated code is to create a test
 * superclass and extend it each time. In all the other test classes, that is what has been
 * done, but this one is done without inheritance to show what it would look like. It is
 * identical in effect to FileEncrypterCaesarKeyTest.
 */
class FileEncrypterCaesarKeyNoSubclassTest {

	private FileEncrypter fe;

	File testInFile;
	File testOutFile;
	
	/*
	 * A word about temporary files. There are clearly situations in which this approach could leave
	 * temporary files in existence. In JUnit 4, there was a Rule that provided a more water-tight
	 * method for managing temporary files, but that has not yet been ported to JUnit 5. You could 
	 * create a JUnit Extension (the replacement for Rules) that does the same, but I decided that
	 * was overkill for this test.
	 */
	@BeforeEach
	void setUp() throws IOException {
		fe = new FileEncrypterCaesarKey("ThE aNsWeR iS 42");		

		testInFile = File.createTempFile("tst", ".txt");	
		testOutFile = File.createTempFile("tst", ".txt");	
		// If the test fails badly, this should cause the files to be deleted eventually
		testInFile.deleteOnExit();
		testOutFile.deleteOnExit();
	}

	@AfterEach
	void tearDown() {
		// Note that while deleteOnExit() is a backup, we don't want to rely on it
		testInFile.delete();
		testOutFile.delete();
	}

	@Test
	void testEncryptFile() throws IOException {
		FileWriter w = new FileWriter(testInFile);
		w.write("Hello World");
		w.close();

		fe.encryptFile(testInFile.getAbsolutePath(), testOutFile.getAbsolutePath());

		List<String> lines = Files.readAllLines(testOutFile.toPath());
		
		assertEquals(1, lines.size());
		assertEquals("vPHHDTcDAHQ", lines.get(0));
	}

	@Test
	void testDecryptFile() throws IOException {
		FileWriter w = new FileWriter(testInFile);
		w.write("vPHHDTcDAHQ");
		w.close();

		fe.decryptFile(testInFile.getAbsolutePath(), testOutFile.getAbsolutePath());

		List<String> lines = Files.readAllLines(testOutFile.toPath());
		
		assertEquals(1, lines.size());
		assertEquals("Hello World", lines.get(0));
	}

}
