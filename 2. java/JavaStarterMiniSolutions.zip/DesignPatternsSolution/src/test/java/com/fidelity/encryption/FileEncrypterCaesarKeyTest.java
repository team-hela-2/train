package com.fidelity.encryption;

class FileEncrypterCaesarKeyTest extends AbstractFileEncrypterTest {

	@Override
	FileEncrypter getFileEncrypter() {
		return new FileEncrypterCaesarKey("ThE aNsWeR iS 42");
	}

	@Override
	String getPlaintext() {
		return "Hello World";
	}

	@Override
	String getCiphertext() {
		return "vPHHDTcDAHQ";
	}

}
