package com.fidelity.encryption;

class FileEncrypterPlayfairTest extends AbstractFileEncrypterTest {

	@Override
	FileEncrypter getFileEncrypter() {
		return new FileEncrypterPlayfair("ThE aNsWeR iS 42");
	}

	@Override
	String getPlaintext() {
		return "Hello World";
	}

	@Override
	String getCiphertext() {
		return "C4rumpaTpkoZ";
	}
}
