package com.fidelity.encryption;

class FileEncrypterSimpleCaesarTest extends AbstractFileEncrypterTest {

	@Override
	FileEncrypter getFileEncrypter() {
		return new FileEncrypterSimpleCaesar("1");
	}

	@Override
	String getPlaintext() {
		return "Hello World";
	}

	@Override
	String getCiphertext() {
		return "Ifmmp0Xpsme";
	}
}
