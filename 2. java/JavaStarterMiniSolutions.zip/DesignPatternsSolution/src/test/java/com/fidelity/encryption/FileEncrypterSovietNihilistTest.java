package com.fidelity.encryption;

class FileEncrypterSovietNihilistTest extends AbstractFileEncrypterTest {

	@Override
	FileEncrypter getFileEncrypter() {
		return new FileEncrypterSovietNihilist("3517269,Nihilist");
	}

	@Override
	String getPlaintext() {
		return "Hello World";
	}

	@Override
	String getCiphertext() {
		return "78789 86805 89631 18797";
	}

}
