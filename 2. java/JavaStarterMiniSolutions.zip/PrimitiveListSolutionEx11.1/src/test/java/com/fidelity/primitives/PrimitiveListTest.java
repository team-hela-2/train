package com.fidelity.primitives;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class PrimitiveListTest {
	
	PrimitiveList p;
	
	@BeforeEach
	void setUp() {
		p = new PrimitiveList();
	}

    @Test
    void testNoNegatives() {
        List<Integer> values = new ArrayList<>(Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9));
        p.removeNegatives(values);
        checkNonNegativeSize(9, values);
    }

    @Test
    void testAllNegatives() {
        List<Integer> values = new ArrayList<>(Arrays.asList(-1, -2, -3, -4, -5, -6, -7, -8, -9));
        p.removeNegatives(values);
        checkNonNegativeSize(0, values);
    }

    @Test
    void testSomeNegatives() {
        List<Integer> values = new ArrayList<>(Arrays.asList(-1, 2, -3, 4, -5, 6, -7, 8, -9));
        p.removeNegatives(values);
        checkNonNegativeSize(4, values);
    }

    @Test
    void testNoNegativesByIterator() {
        List<Integer> values = new ArrayList<>(Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9));
        p.removeNegativesByIterator(values);
        checkNonNegativeSize(9, values);
    }

    @Test
    void testAllNegativesByIterator() {
        List<Integer> values = new ArrayList<>(Arrays.asList(-1, -2, -3, -4, -5, -6, -7, -8, -9));
        p.removeNegativesByIterator(values);
        checkNonNegativeSize(0, values);
    }

    @Test
    void testSomeNegativesByIterator() {
        List<Integer> values = new ArrayList<>(Arrays.asList(-1, 2, -3, 4, -5, 6, -7, 8, -9));
        p.removeNegativesByIterator(values);
        checkNonNegativeSize(4, values);
    }

    @Test
    void testConvertingNumbers() {
        List<String> values = new ArrayList<>(Arrays.asList("-1", "2", "-3", "4", "-5", "6", "-7", "8", "-9"));
        List<Integer> output = p.removeNegativesFromString(values);
        List<Integer> expected = new ArrayList<>(Arrays.asList(2, 4, 6, 8));
        assertEquals(expected, output);
        checkNonNegativeSize(4, output);
    }

    @Test
    void testConvertingNonNumbers() {
        List<String> values = new ArrayList<>(Arrays.asList("-1", "2", "a", "&"));
        List<Integer> output = p.removeNegativesFromString(values);
        assertEquals(0, output.size());
    }


    // Utility method
    private void checkNonNegativeSize(int size, List<Integer> values) {
    	assertEquals(size, values.size());
        for (int i : values) {
            if (i < 0) {
                fail("List still contains a negative");
            }
        }
    }
}
