package com.fidelity.media;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.Objects;

public class Audio extends Media {

	private int totalStreamingTimes;

	public Audio(BigDecimal purchasePrice, LocalDate releaseDate,String mediaID, int totalStreamingTimes) {
		
		super(purchasePrice, releaseDate,mediaID);
		if(totalStreamingTimes>0) {
			this.totalStreamingTimes  = totalStreamingTimes ;
		}
		else {
			throw new IllegalArgumentException("Please provide valid streaming time.");
		}			
	}
	
	
	@Override
	public String toString() {
		return "Audio [totalStreamingTimes=" + totalStreamingTimes + "]";
	}
	
	@Override
	public BigDecimal getRevenue() {
		return super.getPurchasePrice().multiply(new BigDecimal(totalStreamingTimes)).setScale(2, RoundingMode.HALF_EVEN);
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + Objects.hash(totalStreamingTimes);
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Audio other = (Audio) obj;
		return totalStreamingTimes == other.totalStreamingTimes;
	}
	
	

}
