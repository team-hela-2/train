package com.fidelity.media;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Objects;

public abstract class Media {
	private BigDecimal purchasePrice;
	private LocalDate releaseDate;
	private String mediaID;

	public Media(BigDecimal purchasePrice,LocalDate releaseDate, String mediaID ) {
		this.purchasePrice = purchasePrice;
		this.releaseDate = releaseDate;
		this.mediaID = mediaID;
	}

	
	public abstract BigDecimal getRevenue();
	
	@Override
	public int hashCode() {
		return Objects.hash(mediaID, purchasePrice, releaseDate);
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Media other = (Media) obj;
		return Objects.equals(mediaID, other.mediaID) && Objects.equals(purchasePrice, other.purchasePrice)
				&& Objects.equals(releaseDate, other.releaseDate);
	}


	public BigDecimal getPurchasePrice() {
		return this.purchasePrice;
	}
	
	public LocalDate getReleaseDate() {
		return this.releaseDate;
	}


	public String getMediaID() {
		return this.mediaID;
	}


	@Override
	public String toString() {
		return "Media [purchasePrice=" + purchasePrice + ", releaseDate=" + releaseDate + ", mediaID=" + mediaID + "]";
	}
}
