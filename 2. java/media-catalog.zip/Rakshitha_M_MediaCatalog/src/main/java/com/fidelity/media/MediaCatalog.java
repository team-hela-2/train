package com.fidelity.media;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Objects;

public class MediaCatalog {
	private int maxRecordings;
	private ArrayList<Media> recordings = new ArrayList<Media>();

	public MediaCatalog(int maxRecordings) {
		if(maxRecordings>0)
			this.maxRecordings = maxRecordings;
		else
			throw new IllegalArgumentException("Please enter a valid number");
	}


	public void addRecording(String type, BigDecimal purchasePrice, LocalDate releaseDate, String mediaID, int totalStreamingTimes) {
		if(recordings.size()< this.maxRecordings) {
			Media media;
			if(type=="audio") {
				media = new Audio(purchasePrice, releaseDate,mediaID, totalStreamingTimes);
				recordings.add(media);
			}
			else {
				throw new IllegalArgumentException("Please choose either audio or video.");
			}
		}
		else {
			throw new IllegalArgumentException("Catalog has reached maximum number of recordings");
		}
	}
	
	public void addRecording(String type, BigDecimal purchasePrice, LocalDate releaseDate, String mediaID, double runtime) {
		if(recordings.size()< this.maxRecordings) {
			Media media;
			if(type=="video") {
				media = new Video(purchasePrice, releaseDate,mediaID, runtime);
				recordings.add(media);
			}
			else {
				throw new IllegalArgumentException("Please choose either audio or video.");
			}
		}
		else {
			throw new IllegalArgumentException("Catalog has reached maximum number of recordings");
		}
	}


	public int getRecordingsCanBeAdded() {
		return maxRecordings - recordings.size();
	}
	
	public int getMaxRecordings() {
		return maxRecordings;
	}
	
	public int totalRecordings() {
		return recordings.size();
	}
	
	public BigDecimal totalRevenue() {
		BigDecimal sum= new BigDecimal(0);
		for(Media recording : recordings) {
			sum=sum.add(recording.getRevenue());
		}
		return sum;
	}


	public void removeRecording(String mediaID) {
		for(Media recording : recordings) {
			if(recording.getMediaID() == mediaID)
			{
				recordings.remove(recording);
				return;
			}
		}
		throw new IllegalArgumentException("Recording "+mediaID+" not found.");
	}


	@Override
	public String toString() {
		return "MediaCatalog [maxRecordings=" + maxRecordings + ", recordings=" + recordings + "]";
	}


	@Override
	public int hashCode() {
		return Objects.hash(maxRecordings, recordings);
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MediaCatalog other = (MediaCatalog) obj;
		return maxRecordings == other.maxRecordings && Objects.equals(recordings, other.recordings);
	}
	
	
}

