package com.fidelity.media;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.Objects;

public class Video extends Media {
	private double runtime;

	public Video(BigDecimal purchasePrice, LocalDate releaseDate,String mediaID, double runtime) {
		super(purchasePrice, releaseDate,mediaID);
		if(runtime>0)
			this.runtime = runtime;
		else
			throw new IllegalArgumentException("Please provide valid runtime in minutes.");
	}
	
	@Override
	public String toString() {
		return "Video [runtime=" + runtime + "]";
	}
	
	@Override
	public BigDecimal getRevenue() {
		BigDecimal revenue = new BigDecimal(this.runtime).multiply(new BigDecimal(0.1));
		if(super.getReleaseDate().isAfter(LocalDate.now().minusMonths(3)) )
			return revenue.add(new BigDecimal(7.00)).setScale(2, RoundingMode.HALF_EVEN);
		else {
			return revenue.setScale(2, RoundingMode.HALF_EVEN);
		}
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + Objects.hash(runtime);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Video other = (Video) obj;
		return Double.doubleToLongBits(runtime) == Double.doubleToLongBits(other.runtime);
	}
	
	
}
