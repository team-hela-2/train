package com.fidelity.media;

import static org.junit.jupiter.api.Assertions.*;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.UUID;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class AudioTest {

Audio audio;
	
	@BeforeEach
	void setUp() throws Exception {
		String mediaID = UUID.randomUUID().toString();
		BigDecimal purchasePrice= new BigDecimal(5000);
		LocalDate realeaseDate = LocalDate.now();
		int totalStreamingTimes = 5;
		audio = new Audio(purchasePrice, realeaseDate, mediaID, totalStreamingTimes);
	}

	@AfterEach
	void tearDown() throws Exception {
		audio=null;
	}
	
	@Test
	void test() {
		assertNotNull(audio);
	}
	
	@Test
	void testGetRevenue() {
		BigDecimal revenue = audio.getRevenue();
	    assertEquals(revenue,new BigDecimal(25000.00).setScale(2, RoundingMode.HALF_EVEN));
	}
	
	@Test
	void testInvalidStreamingTimes() {
		String mediaID = UUID.randomUUID().toString();
		BigDecimal purchasePrice= new BigDecimal(5000);
		LocalDate realeaseDate = LocalDate.now();
		int totalStreamingTimes = -1;
		try {
			audio = new Audio(purchasePrice, realeaseDate, mediaID, totalStreamingTimes);
			}
			catch(IllegalArgumentException e){
				assertEquals(e.getMessage(),"Please provide valid streaming time." );
			};
	}
}
