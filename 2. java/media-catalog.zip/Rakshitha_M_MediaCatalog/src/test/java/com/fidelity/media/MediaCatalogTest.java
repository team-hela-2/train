package com.fidelity.media;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.UUID;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


public class MediaCatalogTest {
	MediaCatalog catalog;
	
	@BeforeEach
	void setUp() throws Exception {
		int maxRecordings= 5;
		catalog = new MediaCatalog(maxRecordings);
	}

	@AfterEach
	void tearDown() throws Exception {
		catalog=null;
	}
	
	@Test
	void test() {
		assertNotNull(catalog);
	}
	
	@Test
	void testAddRecording() {
		String type="audio";
		String mediaID = UUID.randomUUID().toString();
		BigDecimal purchasePrice= new BigDecimal(5000);
		LocalDate realeaseDate = LocalDate.now();
		int totalStreamingTimes = 5;
		catalog.addRecording(type,purchasePrice,realeaseDate,mediaID, totalStreamingTimes);
		type="video";
		mediaID = UUID.randomUUID().toString();
		purchasePrice= new BigDecimal(10000);
		realeaseDate = LocalDate.now();
		double runtime = 23.5;
		catalog.addRecording(type,purchasePrice,realeaseDate,mediaID,runtime);
		int recordingsSpaceLeft = catalog.getRecordingsCanBeAdded();
		assertEquals(recordingsSpaceLeft, 3);
	}
	
	@Test
	void testRecordingSpaceLeft() {
		String type="audio";
		String mediaID = UUID.randomUUID().toString();
		BigDecimal purchasePrice= new BigDecimal(5000);
		LocalDate realeaseDate = LocalDate.now();
		int totalStreamingTimes = 5;
		catalog.addRecording(type,purchasePrice,realeaseDate, mediaID, totalStreamingTimes);
		int recordings= catalog.getRecordingsCanBeAdded();
		assertEquals(recordings, 4);
	}
	
	@Test
	void testMaxRecordings() {
		int recordings= catalog.getMaxRecordings();
		assertEquals(recordings, 5);
	}
	
	@Test
	void testTotalRecordings() {
		String type="audio";
		String mediaID = UUID.randomUUID().toString();
		BigDecimal purchasePrice= new BigDecimal(5000);
		LocalDate realeaseDate = LocalDate.now();
		int totalStreamingTimes = 5;
		catalog.addRecording(type,purchasePrice,realeaseDate,mediaID, totalStreamingTimes);
		type="video";
		mediaID = UUID.randomUUID().toString();
		purchasePrice= new BigDecimal(10000);
		realeaseDate = LocalDate.now();
		double runtime = 23.5;
		catalog.addRecording(type,purchasePrice,realeaseDate, mediaID, runtime);
		mediaID = UUID.randomUUID().toString();
		purchasePrice= new BigDecimal(15000);
		realeaseDate = LocalDate.now();
		runtime = 90.5;
		catalog.addRecording(type,purchasePrice,realeaseDate,mediaID, runtime);
		int recordings = catalog.totalRecordings();
		assertEquals(recordings, 3);
	}
	
	@Test
	void getTotalRevenue() {
		String type="audio";
		String mediaID = UUID.randomUUID().toString();
		BigDecimal purchasePrice= new BigDecimal(5000);
		LocalDate realeaseDate = LocalDate.now();
		int totalStreamingTimes = 5;
		catalog.addRecording(type,purchasePrice,realeaseDate,mediaID, totalStreamingTimes);
		
		type="video";
		mediaID = UUID.randomUUID().toString();
		purchasePrice= new BigDecimal(10000);
		realeaseDate = LocalDate.now();
		double runtime = 23.5;
		catalog.addRecording(type,purchasePrice,realeaseDate,mediaID,runtime);
		
		mediaID = UUID.randomUUID().toString();
		purchasePrice= new BigDecimal(15000);
		realeaseDate = LocalDate.of(2022, 8,12);
		runtime = 90.5;
		catalog.addRecording(type,purchasePrice,realeaseDate,mediaID,runtime);
		
		BigDecimal totalRevenue = catalog.totalRevenue();
		assertEquals(totalRevenue, new BigDecimal(25025.40).setScale(2, RoundingMode.HALF_EVEN));
	}
	
	@Test
	void testRemoveRecording() {
		String type="audio";
		String mediaID = UUID.randomUUID().toString();
		BigDecimal purchasePrice= new BigDecimal(5000);
		LocalDate realeaseDate = LocalDate.now();
		int totalStreamingTimes = 5;
		catalog.addRecording(type,purchasePrice,realeaseDate,mediaID, totalStreamingTimes);
		
		type="video";
		mediaID = UUID.randomUUID().toString();
		purchasePrice= new BigDecimal(10000);
		realeaseDate = LocalDate.now();
		double runtime = 23.5;
		catalog.addRecording(type,purchasePrice,realeaseDate,mediaID,runtime);
		
		mediaID = "remove3";
		purchasePrice= new BigDecimal(15000);
		realeaseDate = LocalDate.of(2022, 8,12);
		runtime = 90.5;
		catalog.addRecording(type,purchasePrice,realeaseDate,mediaID,runtime);
		
		int recordings= catalog.getRecordingsCanBeAdded();
		assertEquals(recordings, 2);
		catalog.removeRecording(mediaID);
		recordings= catalog.getRecordingsCanBeAdded();
		assertEquals(recordings, 3);
		
	}
	
	@Test
	void testCatalogLimit() {
		String type="audio";
		String mediaID = UUID.randomUUID().toString();
		BigDecimal purchasePrice= new BigDecimal(5000);
		LocalDate realeaseDate = LocalDate.now();
		int totalStreamingTimes = 5;
		try {
			catalog.addRecording(type,purchasePrice,realeaseDate,mediaID, totalStreamingTimes);
			catalog.addRecording(type,purchasePrice,realeaseDate,mediaID, totalStreamingTimes);
			catalog.addRecording(type,purchasePrice,realeaseDate,mediaID, totalStreamingTimes);
			catalog.addRecording(type,purchasePrice,realeaseDate,mediaID, totalStreamingTimes);
			catalog.addRecording(type,purchasePrice,realeaseDate,mediaID, totalStreamingTimes);
			catalog.addRecording(type,purchasePrice,realeaseDate,mediaID, totalStreamingTimes);
		}
		catch(IllegalArgumentException e){
			assertEquals(e.getMessage(),"Catalog has reached maximum number of recordings" );
		};
	}
	
	@Test
	void testRemoveRecordingError() {
		String type="audio";
		String mediaID = UUID.randomUUID().toString();
		BigDecimal purchasePrice= new BigDecimal(5000);
		LocalDate realeaseDate = LocalDate.now();
		int totalStreamingTimes = 5;
		catalog.addRecording(type,purchasePrice,realeaseDate,mediaID, totalStreamingTimes);
		String testID = "randomID";
		try {
		catalog.removeRecording(testID);
		}
		catch(IllegalArgumentException e){
			assertEquals(e.getMessage(),"Recording "+testID+ " not found." );
		};
	}
	
	@Test
	void testCatalogErr() {
		int maxRecordings= -1;
		try {

			MediaCatalog catalog = new MediaCatalog(maxRecordings);
			}
		catch(IllegalArgumentException i){
			assertEquals(i.getMessage(),"Please enter a valid number" );
		};
	}
	
	@Test
	void testMediaTypeErr() {
		String type="audioing";
		String mediaID = UUID.randomUUID().toString();
		BigDecimal purchasePrice= new BigDecimal(5000);
		LocalDate realeaseDate = LocalDate.now();
		int totalStreamingTimes = 5;
		try {
			catalog.addRecording(type,purchasePrice,realeaseDate,mediaID, totalStreamingTimes);
		}
		catch(IllegalArgumentException i){
			assertEquals(i.getMessage(),"Please choose either audio or video." );
		};
	}
	
}
