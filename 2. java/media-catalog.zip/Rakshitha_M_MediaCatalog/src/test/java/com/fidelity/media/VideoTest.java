package com.fidelity.media;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.UUID;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class VideoTest {

	Video video;
	@BeforeEach
	void setUp() throws Exception {
		String mediaID = UUID.randomUUID().toString();
		BigDecimal purchasePrice= new BigDecimal(5000);
		LocalDate realeaseDate = LocalDate.now();
		double runtime = 23.5;	
		video = new Video(purchasePrice, realeaseDate, mediaID, runtime);
	}

	@AfterEach
	void tearDown() throws Exception {
		video=null;
	}
	
	@Test
	void test() {
		assertNotNull(video);
	}
	
	@Test
	void testGetRevenue() {
		BigDecimal revenue = video.getRevenue();
	    assertEquals(revenue,new BigDecimal(9.35).setScale(2, RoundingMode.HALF_EVEN));
	}
	
	@Test
	void testInvalidStreamingTimes() {
		String mediaID = UUID.randomUUID().toString();
		BigDecimal purchasePrice= new BigDecimal(5000);
		LocalDate realeaseDate = LocalDate.now();
		double runtime = 0.0;
		try {
			video = new Video(purchasePrice, realeaseDate, mediaID, runtime);
			}
			catch(IllegalArgumentException e){
				assertEquals(e.getMessage(),"Please provide valid runtime in minutes." );
			};
	}
}
