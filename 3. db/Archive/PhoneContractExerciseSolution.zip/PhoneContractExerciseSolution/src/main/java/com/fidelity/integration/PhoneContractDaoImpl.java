package com.fidelity.integration;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fidelity.model.PhoneContract;

public class PhoneContractDaoImpl implements PhoneContractDao {
	private final Logger logger = LoggerFactory.getLogger(PhoneContractDaoImpl.class);

	private Connection conn;
	
	@Override
	public List<PhoneContract> getFullPhoneContracts() {
		
		String sql = "SELECT pc.pcid, pc.pcname, " +
				"coalesce(r.ratesname,'N/A') r_name," +
				"coalesce(h.hours_quantity,0) h_quantity," + 
				"coalesce(h.hours_quantity,0)* coalesce(r.ratesprice,0.0) value " + 
				"FROM b_phonecontracts pc " + 
				"LEFT OUTER JOIN b_hours h " + 
				"ON h.pcid = pc.pcid " + 
				"LEFT OUTER JOIN b_rates r " + 
				"ON h.ratesid = r.ratesid " + 
				"ORDER BY pc.pcname ";
		List<PhoneContract> details = new ArrayList<>();

		Connection conn = getConnection();
		try (Statement stmt = conn.createStatement()) {
			ResultSet rs = stmt.executeQuery(sql);
			details = handleResults(rs);		
		} catch (SQLException e) {
			logger.error("Cannot execute getFullPhoneContracts", e);
			throw new DatabaseException("Cannot execute getFullPhoneContracts", e);
		}
		return details;
	}

	private List<PhoneContract> handleResults(ResultSet rs) throws SQLException {
		List<PhoneContract> details = new ArrayList<>();
		while (rs.next()) {
			int pcId = rs.getInt("pcid");
			String pcName = rs.getString("pcname");
			String rateName = rs.getString("r_name");
			int quantity = rs.getInt("h_quantity");
			BigDecimal totalValue = rs.getBigDecimal("value");
			PhoneContract detail = new PhoneContract(pcId, pcName, rateName,
							quantity, totalValue);
			details.add(detail);
		}
		return details;
	}

	@Override
	public List<PhoneContract> getPhoneContractByID(int pcId) {
		String sql = "SELECT pc.pcid, pc.pcname, " +
				"coalesce(r.ratesname,'N/A') r_name," +
				"coalesce(h.hours_quantity,0) h_quantity," + 
				"coalesce(h.hours_quantity,0)* coalesce(r.ratesprice,0.0) value " + 
				"FROM b_phonecontracts pc " + 
				"LEFT OUTER JOIN b_hours h " + 
				"ON h.pcid = pc.pcid " + 
				"LEFT OUTER JOIN b_rates r " + 
				"ON h.ratesid = r.ratesid " +
				"WHERE pc.pcid = ? " +
				"ORDER BY pc.pcname ";
		List<PhoneContract> details = new ArrayList<>();

		Connection conn = getConnection();
		try (PreparedStatement stmt = conn.prepareStatement(sql)) {
			stmt.setInt(1, pcId);
			ResultSet rs = stmt.executeQuery();
			details = handleResults(rs);		
		} catch (SQLException e) {
			logger.error("Cannot execute getPhoneContractByID", e);
			throw new DatabaseException("Cannot execute getPhoneContractByID", e);
		}
		return details;
	}


	@Override
	public void close() {
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				throw new DatabaseException("Cannot close connection", e);
			} finally {
				conn = null;
			}
		}
	}

	private Connection getConnection() {
		if (conn == null) {
			Properties properties = new Properties();
			try {
				properties.load(this.getClass().getClassLoader().getResourceAsStream("db.properties"));
				String dbUrl = properties.getProperty("db.url");
				String user = properties.getProperty("db.username");
				String password = properties.getProperty("db.password");

				conn = DriverManager.getConnection(dbUrl, user, password);
			} catch (IOException e) {
				logger.error("Cannot read db.properties", e);
				throw new DatabaseException("Cannot read db.properties", e);
			} catch (SQLException e) {
				logger.error("Cannot connect", e);
				throw new DatabaseException("Cannot connect", e);
			}
		}
		return conn;
	}

}
