package com.fidelity.services;

import java.math.BigDecimal;
import java.util.List;

import com.fidelity.model.PhoneContract;

public class PhoneContractServiceImpl implements PhoneContractService {

	@Override
	public BigDecimal calculateTotalValue(List<PhoneContract> details) {
		BigDecimal totalValue = new BigDecimal("0");
		for (PhoneContract pc : details) {
			totalValue = totalValue.add(pc.getTotalValue());
		}
		
		return totalValue;
	}

}
