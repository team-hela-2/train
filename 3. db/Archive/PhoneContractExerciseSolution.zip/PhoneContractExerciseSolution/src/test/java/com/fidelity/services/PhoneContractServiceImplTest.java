package com.fidelity.services;

import static org.junit.jupiter.api.Assertions.*;

import java.math.BigDecimal;
import java.util.List;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.fidelity.integration.PhoneContractDaoImpl;
import com.fidelity.model.PhoneContract;

class PhoneContractServiceImplTest {
	PhoneContractDaoImpl dao;
	PhoneContractServiceImpl pcs;
	

	@BeforeEach
	void setUp() throws Exception {
		dao = new PhoneContractDaoImpl();
		pcs = new PhoneContractServiceImpl();
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	void testCalcTotalValue() {
		List<PhoneContract> details = dao.getFullPhoneContracts();
		assertNotNull(details);
		assertEquals(new BigDecimal("195.56"), pcs.calculateTotalValue(details));

	}

}
