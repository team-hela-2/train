package com.fidelity.integration;

import java.sql.Connection;
import java.sql.SQLException;

import javax.sql.DataSource;

public class TransactionManager {
	private DataSource dataSource;

	public TransactionManager(DataSource dataSource) {
		super();
		this.dataSource = dataSource;
	}

	public void startTransaction() {
		try {
			Connection connection = dataSource.getConnection();
			connection.setAutoCommit(false);
		} catch (SQLException e) {
			throw new DatabaseException("Unable to begin a transaction", e);
		}
	}

	public void commitTransaction() {
		try {
			Connection connection = dataSource.getConnection();
			connection.commit();
		} catch (SQLException e) {
			throw new DatabaseException("Unable to commit a transaction", e);
		}
	}

	public void rollbackTransaction() {
		try {
			Connection connection = dataSource.getConnection();
			connection.rollback();
		} catch (SQLException e) {
			throw new DatabaseException("Unable to rollback a transaction", e);
		}
	}
}
