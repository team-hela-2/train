package com.fidelity.integration;

import static org.junit.jupiter.api.Assertions.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import javax.sql.DataSource;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import com.fidelity.model.Employee;

class EmployeeDaoQueryTest {
	SimpleDataSource datasource;
	EmployeeDao dao;
	Employee emp7369;
	Employee emp7934;

	@BeforeEach
	void setUp() throws Exception {
		datasource = new SimpleDataSource();
		dao = new EmployeeDaoOracleImpl(datasource);
		
		LocalDate hireDate = LocalDate.parse("1980-12-17");
		emp7369 = new Employee(7369, "SMITH", "CLERK", 7902, hireDate, new BigDecimal("800.00"), null, 20);
		
		hireDate = LocalDate.parse("1982-01-23");
		emp7934 = new Employee(7934, "MILLER", "CLERK", 7782, hireDate, new BigDecimal("1300.00"), null, 10);
}

	@AfterEach
	void tearDown() throws Exception {
		datasource.shutdown();
	}

	/***** Query Tests *****/
	@Test
	void testQueryAllEmployees() {
		List<Employee> emps = dao.queryAllEmployees();
		assertEquals(14, emps.size(), "Should be 14 records");
		assertTrue(emps.contains(emp7369), "Should contain SMITH 7369");
		assertTrue(emps.contains(emp7934), "Should contain MILLER 7934");
	}

	@Test
	void testQueryEmployeeByNumber() {
		int id = 7369;
		Employee emp = dao.queryEmployeeById(id);
		assertEquals(id, emp.getEmpNumber());
	}
	
	@ParameterizedTest
	@ValueSource(ints = {7369, 7499, 7839})
	void testQueryEmployeeById(int id) {
		Employee emp = dao.queryEmployeeById(id);
		assertEquals(id, emp.getEmpNumber());
	}

	@ParameterizedTest
	@ValueSource(strings = { "SMITH", "MILLER" })
	void testQueryEmployeeByName(String name) {
		List<Employee> employees = dao.queryEmployeeByName(name);
		assertNotNull(employees);
		for (Employee employee : employees) {
			assertEquals(employee.getEmpName(), name);
		}
	}

	@Test 
	void testNoSqlInjection() {
		String name = "BobbyTables' OR '1' = '1";
		List<Employee> employees = dao.queryEmployeeByName(name);
		assertEquals(employees.size(), 0);		
	}

	@ParameterizedTest
	@ValueSource(ints = { 10, 20 })
	void testQueryEmployeeByDepartment(int departmentId) {
		List<Employee> employees = dao.queryEmployeeByDepartment(departmentId);
		assertNotNull(employees);
		for (Employee employee : employees) {
			assertEquals(employee.getDeptNumber(), departmentId);
		}
	}

	@ParameterizedTest
	@ValueSource(ints = {7369, 7499, 7521})
	void testQueryEmployeeByIdWithPerformance(int id) {
		Employee emp = dao.queryEmployeeByIdWithPerformance(id);
		assertEquals(id, emp.getEmpNumber());
		assertNotNull(emp.getPerformance());
	}
	
	@ParameterizedTest
	@ValueSource(ints = {7900, 7902, 7934})
	void testQueryEmployeeByIdWithNoPerformance(int id) {
		Employee emp = dao.queryEmployeeByIdWithPerformance(id);
		assertEquals(id, emp.getEmpNumber());
		assertNull(emp.getPerformance());
	}

}
