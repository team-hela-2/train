package com.fidelity.services;

import java.math.BigDecimal;
import java.util.List;

import com.fidelity.integration.EmployeeDao;
import com.fidelity.model.Employee;

public class EmployeeManagementService {
	private EmployeeDao dao;
	
	public EmployeeManagementService(EmployeeDao dao) {
		this.dao = dao;
	}

	public Employee insertNewManager(Employee manager, List<Employee> employees) {
		Employee newManager = null;
		
		newManager = dao.insertEmployee(manager);
		int managerId = manager.getEmpNumber();
		
		for (Employee employee : employees) {
			employee.setMgrNumber(managerId);
			dao.updateEmployee(employee);
		}
		
		return newManager;
	}

}
