package com.fidelity.integration;

import java.util.List;

import javax.sql.DataSource;

import com.fidelity.model.Employee;

public abstract class EmployeeDao {
	protected DataSource dataSource;
	
	public EmployeeDao(DataSource datasource) {
		this.dataSource = datasource;
	}
	
	public abstract List<Employee> queryAllEmployees();

	public abstract Employee queryEmployeeById(int empNo);

	public abstract List<Employee> queryEmployeeByName(String name);
	
	public abstract List<Employee> queryEmployeeByDepartment(int departmentId);
}
