package com.fidelity.services;

import java.util.List;

import com.fidelity.model.Employee;

public interface EmployeeManagementService {

	Employee insertNewManager(Employee manager, List<Employee> employees);

}