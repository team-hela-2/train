package com.fidelity.services;

import java.util.List;

import com.fidelity.integration.TransactionManager;
import com.fidelity.model.Employee;

public class EmployeeManagementServiceProxy implements EmployeeManagementService {
	private EmployeeManagementService service;
	private TransactionManager transactionManager;
		
	public EmployeeManagementServiceProxy(EmployeeManagementService service,
			TransactionManager transactionManager) {
		super();
		this.service = service;
		this.transactionManager = transactionManager;
	}

	@Override
	public Employee insertNewManager(Employee manager, List<Employee> employees) {
		transactionManager.startTransaction();

		Employee employee = service.insertNewManager(manager, employees);
		
		transactionManager.commitTransaction();
		
		return employee;
	}

}
