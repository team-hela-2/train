package com.fidelity.services;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InOrder;
import org.mockito.Mockito;

import com.fidelity.integration.TransactionManager;
import com.fidelity.model.Employee;

import static org.mockito.Mockito.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

class EmployeeManagementServiceProxyTest {
	EmployeeManagementService mockService;
	EmployeeManagementServiceProxy proxy;
	TransactionManager mockManager;
	List<Employee> employees;

	@BeforeEach
	void setUp() throws Exception {
		mockService = mock(EmployeeManagementServiceImpl.class);
		mockManager = mock(TransactionManager.class);				
		proxy = new EmployeeManagementServiceProxy(mockService, mockManager);
		employees = buildEmployeesList();
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	void testInsertNewManager() {
		LocalDate hireDate = LocalDate.parse("2021-12-17");
		Employee manager = new Employee(4242, "DILBERT", "MANAGER", 7902, hireDate, new BigDecimal("1200.00"), null, 42);
		List<Employee> employees = new ArrayList<>();
		
		employees.add(new Employee(7369, "SMITH", "CLERK", 7902, hireDate, new BigDecimal("800.00"), null, 20));
		employees.add(new Employee(7934, "MILLER", "CLERK", 7782, hireDate, new BigDecimal("1300.00"), null, 10));
		
		proxy.insertNewManager(manager, employees);
		
		InOrder inOrder = Mockito.inOrder(mockManager, mockService);
		inOrder.verify(mockManager).startTransaction();
		inOrder.verify(mockService).insertNewManager(manager, employees);
		inOrder.verify(mockManager).commitTransaction();
	}

	List<Employee> buildEmployeesList() {
		List<Employee> employees = new ArrayList<>();

		LocalDate hireDate = LocalDate.parse("1980-12-17");
		employees.add(new Employee(7369, "HEYES", "ANALYST", 7934, hireDate, new BigDecimal("500.00"), new BigDecimal("2"), 10));
		
		hireDate = LocalDate.parse("1982-01-23");
		employees.add(new Employee(7934, "MILLER", "CLERK", 7782, hireDate, new BigDecimal("1300.00"), null, 10));

		return employees;
	}
}
