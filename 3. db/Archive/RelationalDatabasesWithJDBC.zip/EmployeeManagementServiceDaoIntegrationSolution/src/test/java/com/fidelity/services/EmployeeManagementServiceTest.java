package com.fidelity.services;

import static org.junit.jupiter.api.Assertions.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import com.fidelity.integration.EmployeeDao;
import com.fidelity.integration.SimpleDataSource;
import com.fidelity.model.Department;
import com.fidelity.model.Employee;

class EmployeeManagementServiceTest {
	EmployeeManagementService service;
	EmployeeDao dao;
	
	@BeforeEach
	void setUp() throws Exception {
		dao = new MockEmployeeDao();
		service = new EmployeeManagementServiceImpl(dao);
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	void testInsertNewManager() {
		LocalDate hireDate = LocalDate.parse("2021-12-17");
		Employee manager = new Employee(4242, "DILBERT", "MANAGER", 7902, hireDate, new BigDecimal("1200.00"), null, 42);
		List<Employee> employees = new ArrayList<>();
		
		employees.add(new Employee(7369, "SMITH", "CLERK", 7902, hireDate, new BigDecimal("800.00"), null, 20));
		employees.add(new Employee(7934, "MILLER", "CLERK", 7782, hireDate, new BigDecimal("1300.00"), null, 10));
		
		Employee newManager = service.insertNewManager(manager, employees);
		
		assertEquals(newManager, manager);
	}
	
}

class MockEmployeeDao extends EmployeeDao{
	List<Employee> employees;
	
	MockEmployeeDao() {
		super(null);
		employees = new ArrayList<>();
		
		employees.add(new Employee(7369, "SMITH", "CLERK", 7902, LocalDate.of(1980, 12,	17), new BigDecimal("800.00"), null, 20));
		employees.add(new Employee(7934, "MILLER", "CLERK", 7782, LocalDate.of(1982, 01, 23), new BigDecimal("1300.00"), null, 10));
	}
	
	public List<Employee> queryAllEmployees() {
		return employees;
	}

	public Employee queryEmployeeById(int empNo) {
		Employee employee = null;
		
		for (Employee emp : employees) {
			if (emp.getEmpNumber() == empNo) {
				employee = emp;
				break;
			}
		}
		return employee;
	}

	@Override
	public Employee insertEmployee(Employee employee) {
		return employee;
	}

	@Override
	public List<Employee> queryEmployeeByName(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Employee> queryEmployeeByDepartment(int departmentId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Employee updateEmployee(Employee employee) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean deleteEmployee(int id) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Employee queryEmployeeByIdWithPerformance(int empNo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Department queryForDepartment(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Department> queryForAllDepartments() {
		// TODO Auto-generated method stub
		return null;
	}


}
