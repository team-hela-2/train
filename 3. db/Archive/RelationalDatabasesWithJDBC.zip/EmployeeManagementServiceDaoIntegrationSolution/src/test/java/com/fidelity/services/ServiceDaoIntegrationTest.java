package com.fidelity.services;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.jdbc.JdbcTestUtils.countRowsInTable;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.jdbc.core.JdbcTemplate;

import com.fidelity.integration.DbTestUtils;
import com.fidelity.integration.EmployeeDao;
import com.fidelity.integration.EmployeeDaoOracleImpl;
import com.fidelity.integration.SimpleDataSource;
import com.fidelity.integration.TransactionManager;
import com.fidelity.model.Employee;

/*
 * The tests in this file are integration tests, not unit tests.
 * The tests have a striking resemblance to the tests in EmployeeManagementServiceTest.
 * But in these tests, the EmployeeManagementService is using the EmployeeDaoOracleImpl
 * not a MockDao.
 * To prevent modifying the Oracle database, a transaction is started before each test
 * and the transaction is rolled back after each test.
 */
class ServiceDaoIntegrationTest {
	JdbcTemplate jdbcTemplate;
	DbTestUtils dbTestUtils;
	EmployeeManagementService service;
	EmployeeDao dao;
	SimpleDataSource dataSource;
	TransactionManager transactionManager;
	Connection connection;
	Employee emp7369;
	Employee emp7934;
	
	@BeforeEach
	void setUp() throws Exception {
		dataSource = new SimpleDataSource();
		dao = new EmployeeDaoOracleImpl(dataSource);
		service = new EmployeeManagementServiceImpl(dao);
		transactionManager = new TransactionManager(dataSource);
		
		transactionManager.startTransaction();
		
		connection = dataSource.getConnection();		
		dbTestUtils = new DbTestUtils(connection);		
		jdbcTemplate = dbTestUtils.initJdbcTemplate();
	}

	@AfterEach
	void tearDown() throws Exception {
		transactionManager.rollbackTransaction();
		dataSource.shutdown();
	}

	@Test
	void testInsertNewManager() {
		int managerId = 42;
		String empQuery = "select * from emp where empno = " + managerId;
		LocalDate hireDate = LocalDate.parse("2021-12-17");
		int departmentId = 10;
		Employee manager = new Employee(managerId, "DILBERT", "MANAGER", 7902, hireDate, new BigDecimal("1200.00"), null, departmentId);
		List<Employee> employees = new ArrayList<>();		
		employees.add(new Employee(7369, "SMITH", "CLERK", 7902, hireDate, new BigDecimal("800.00"), null, 20));
		employees.add(new Employee(7934, "MILLER", "CLERK", 7782, hireDate, new BigDecimal("1300.00"), null, 30));
		
		int oldSize = countRowsInTable(jdbcTemplate, "emp");
		
		assertEquals(0, jdbcTemplate.queryForList(empQuery).size(), "Should not contain new manager before insert");
		
		Employee newManager = service.insertNewManager(manager, employees);
		
		assertEquals(newManager, manager);
		assertEquals(1, jdbcTemplate.queryForList(empQuery).size(), "Should contain new manager after insert");

		int newSize = countRowsInTable(jdbcTemplate, "emp");
		assertEquals(newSize, oldSize + 1);
		
		empQuery = "select * from emp where mgr = " + managerId;
		assertEquals(employees.size(), jdbcTemplate.queryForList(empQuery).size(), "Employees should be updated");
		
		for (Employee employee : employees) {
			assertEquals(managerId, employee.getMgrNumber());
		}
	}
}
