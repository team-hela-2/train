package com.fidelity.services;

import java.math.BigDecimal;
import java.util.List;

import com.fidelity.model.Employee;

public interface EmployeeManagement {

	BigDecimal queryTotalSalary();

	List<Employee> queryAllEmployees();

	Employee queryEmployeeById(int id);

	Employee insertEmployee(Employee employee);

	Employee updateEmployee(Employee employee);

	boolean deleteEmployee(int id);

	Employee insertNewManager(Employee manager, List<Employee> employees);

}