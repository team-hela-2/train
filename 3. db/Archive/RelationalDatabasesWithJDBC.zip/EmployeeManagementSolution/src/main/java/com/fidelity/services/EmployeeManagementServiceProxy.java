package com.fidelity.services;

import java.math.BigDecimal;
import java.util.List;

import com.fidelity.integration.TransactionManager;
import com.fidelity.model.Employee;

public class EmployeeManagementServiceProxy implements EmployeeManagement {
	private EmployeeManagementService service;
	private TransactionManager transactionManager;
	
	public EmployeeManagementServiceProxy(EmployeeManagementService service, TransactionManager manager) {
		this.service = service;
		this.transactionManager = manager;
	}

	@Override
	public BigDecimal queryTotalSalary() {
		BigDecimal salary = service.queryTotalSalary();
		
		return salary;
	}

	@Override
	public List<Employee> queryAllEmployees() {
		List<Employee> employees = service.queryAllEmployees();
		
		return employees;
	}

	@Override
	public Employee queryEmployeeById(int id) {
		Employee employee = service.queryEmployeeById(id);
		
		return employee;
	}

	@Override
	public Employee insertEmployee(Employee employee) {
		transactionManager.startTransaction();
		
		Employee newEmployee = service.insertEmployee(employee);
		
		transactionManager.commitTransaction();
		
		return newEmployee;
	}

	@Override
	public Employee updateEmployee(Employee employee) {
		transactionManager.startTransaction();

		Employee updatedEmployee = service.updateEmployee(employee);
		
		transactionManager.commitTransaction();
		
		return updatedEmployee;
	}

	@Override
	public boolean deleteEmployee(int id) {
		transactionManager.startTransaction();

		boolean success = service.deleteEmployee(id);
		
		transactionManager.commitTransaction();

		return success;
	}

	@Override
	public Employee insertNewManager(Employee manager, List<Employee> employees) {
		transactionManager.startTransaction();

		Employee employee = service.insertNewManager(manager, employees);
		
		transactionManager.commitTransaction();
		
		return employee;
	}

}
