package com.fidelity.integration;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.jdbc.JdbcTestUtils.countRowsInTable;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.SQLException;
import java.time.LocalDate;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.jdbc.core.JdbcTemplate;

import com.fidelity.model.Employee;

class TransactionManagerTest {
	TransactionManager manager;
	SimpleDataSource dataSource;
	Connection connection;
	JdbcTemplate jdbcTemplate;
	DbTestUtils dbTestUtils;	
	EmployeeDao dao;
	
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
		dataSource = new SimpleDataSource();
		manager = new TransactionManager(dataSource);
		
		connection = dataSource.getConnection();
		
		manager.startTransaction();
		
		dbTestUtils = new DbTestUtils(connection);		
		jdbcTemplate = dbTestUtils.initJdbcTemplate();
		
		dao = new EmployeeDaoOracleImpl(dataSource);	
	}

	@AfterEach
	void tearDown() throws Exception {
		manager.rollbackTransaction();
	}

	@Test
	void testTransactionManagerCreated() {
		assertNotNull(manager);
	}

	/***** DML Tests *****/
	@Test
	void testInsertEmployee() throws SQLException {
		int oldSize = countRowsInTable(jdbcTemplate, "emp");
		
		String empQuery = "select * from emp where empno = 8000";
		assertEquals(0, jdbcTemplate.queryForList(empQuery).size(), "Should not contain new values before insert");
		
		LocalDate hireDate = LocalDate.parse("1980-12-17");
		Employee new8000 = new Employee(8000, "HEYES", "ANALYST", 7934, hireDate, new BigDecimal("500.00"), new BigDecimal("2"), 10);
		Employee employee = dao.insertEmployee(new8000);

		assertEquals(new8000, employee, "Returned Employee should equal inserted Employee");
		int newSize = countRowsInTable(jdbcTemplate, "emp");
		assertEquals(oldSize + 1, newSize, "Should have one more employee after insert");
		
		assertEquals(1, jdbcTemplate.queryForList(empQuery).size(), "Should contain new values after insert");
	}

	@Test
	void testUpdateEmployee() throws SQLException {
		int oldSize = countRowsInTable(jdbcTemplate, "emp");
		
		String empQuery = "select * from emp where empno = 7369 and ename = 'HEYES'";
		assertEquals(0, jdbcTemplate.queryForList(empQuery).size(), "Should not contain new values before update");
		
		LocalDate hireDate = LocalDate.parse("1980-12-17");
		Employee upd7369 = new Employee(7369, "HEYES", "ANALYST", 7934, hireDate, new BigDecimal("500.00"), new BigDecimal("2"), 10);
		Employee employee = dao.updateEmployee(upd7369);

		assertEquals(upd7369, employee, "Returned Employee should equal the updated Employee");
		
		int newSize = countRowsInTable(jdbcTemplate, "emp");
		assertEquals(oldSize, newSize, "Should have same number of employees after update");
	}
	
	@Test
	void testDeleteEmployee() throws SQLException {
		int oldSize = countRowsInTable(jdbcTemplate, "emp");

		// delete an employee
		int id = 7369;
		boolean success = dao.deleteEmployee(id);
		
		assertTrue(success, "Delete should return true");
		
		int newSize = countRowsInTable(jdbcTemplate, "emp");
		assertEquals(oldSize - 1, newSize, "Should have one less employee after delete");
	}
	
	@Test
	void testInsertUpdateDeleteInTransaction() {
		// Insert Employee
		int oldSize = countRowsInTable(jdbcTemplate, "emp");
		
		String empQuery = "select * from emp where empno = 8000";
		assertEquals(0, jdbcTemplate.queryForList(empQuery).size(), "Should not contain new values before insert");
		
		LocalDate hireDate = LocalDate.parse("1980-12-17");
		Employee new8000 = new Employee(8000, "HEYES", "ANALYST", 7934, hireDate, new BigDecimal("500.00"), new BigDecimal("2"), 10);
		Employee employee = dao.insertEmployee(new8000);

		assertEquals(new8000, employee, "Returned Employee should equal inserted Employee");
		int newSize = countRowsInTable(jdbcTemplate, "emp");
		assertEquals(oldSize + 1, newSize, "Should have one more employee after insert");
		
		assertEquals(1, jdbcTemplate.queryForList(empQuery).size(), "Should contain new values after insert");

		// Update Employee
		oldSize = countRowsInTable(jdbcTemplate, "emp");
		
		empQuery = "select * from emp where empno = 7369 and ename = 'HEYES'";
		assertEquals(0, jdbcTemplate.queryForList(empQuery).size(), "Should not contain new values before update");
		
		hireDate = LocalDate.parse("1980-12-17");
		Employee upd7369 = new Employee(7369, "HEYES", "ANALYST", 7934, hireDate, new BigDecimal("500.00"), new BigDecimal("2"), 10);
		employee = dao.updateEmployee(upd7369);

		assertEquals(upd7369, employee, "Returned Employee should equal the updated Employee");
		
		newSize = countRowsInTable(jdbcTemplate, "emp");
		assertEquals(oldSize, newSize, "Should have same number of employees after update");
		
		// Delete Employee
		oldSize = countRowsInTable(jdbcTemplate, "emp");

		// delete an employee
		int id = 7369;
		boolean success = dao.deleteEmployee(id);
		
		assertTrue(success, "Delete should return true");
		
		newSize = countRowsInTable(jdbcTemplate, "emp");
		assertEquals(oldSize - 1, newSize, "Should have one less employee after delete");		
	}
}
