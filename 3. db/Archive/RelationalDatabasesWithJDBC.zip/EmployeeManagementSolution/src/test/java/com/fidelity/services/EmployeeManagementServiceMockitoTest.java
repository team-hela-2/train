package com.fidelity.services;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.fidelity.integration.EmployeeDao;
import com.fidelity.model.Employee;

import static org.mockito.Mockito.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

class EmployeeManagementServiceMockitoTest {
	EmployeeManagement service;
	EmployeeDao mockDao;
	List<Employee> employees;

	@BeforeEach
	void setUp() throws Exception {
		mockDao = mock(EmployeeDao.class);
		service = new EmployeeManagementService(mockDao);

		employees = buildEmployeesList();
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	void testQueryTotalSalary() {
		when(mockDao.queryAllEmployees()).thenReturn(employees);
		BigDecimal expected = new BigDecimal("1800");
		BigDecimal actual = service.queryTotalSalary();

		assertEquals(actual.compareTo(expected), 0);
	}

	@Test
	void testQueryAllEmployees() {
		when(mockDao.queryAllEmployees()).thenReturn(employees);

		List<Employee> emps = service.queryAllEmployees();
		assertEquals(2, emps.size(), "Should be 2 records");
	}

	@Test
	void testQueryEmployeeById() {
		int id = 7369;
		LocalDate hireDate = LocalDate.parse("1980-12-17");
		Employee emp7369 = new Employee(7369, "HEYES", "ANALYST", 7934, hireDate, new BigDecimal("500.00"), new BigDecimal("2"), 10);
		
		when(mockDao.queryEmployeeById(id))
					.thenReturn(emp7369);

		Employee emp = service.queryEmployeeById(id);
		assertEquals(id, emp.getEmpNumber());
	}

	@Test
	void testInsertEmployee() {
		int id = 8000;
		LocalDate hireDate = LocalDate.parse("1980-12-17");
		Employee new8000 = new Employee(id, "HEYES", "ANALYST", 7934, hireDate, new BigDecimal("500.00"), new BigDecimal("2"), 10);

		when(mockDao.insertEmployee(new8000))
					.thenReturn(new8000);
		
		Employee employee = service.insertEmployee(new8000);

		assertEquals(new8000, employee, "Returned Employee should equal inserted Employee");

	}

	@Test
	void testUpdateEmployee() {
		LocalDate hireDate = LocalDate.parse("1980-12-17");
		Employee upd7369 = new Employee(7369, "HEYES", "ANALYST", 7934, hireDate, new BigDecimal("500.00"), new BigDecimal("2"), 10);
		
		when(mockDao.updateEmployee(upd7369))
					.thenReturn(upd7369);
		
		Employee employee = service.updateEmployee(upd7369);
		
		assertEquals(upd7369, employee, "Returned Employee should equal the updated Employee");		
	}

	@Test
	void testDeleteEmployee() {
		int id = 7369;
		
		when(mockDao.deleteEmployee(id))
					.thenReturn(true);
		
		boolean success = service.deleteEmployee(id);
		
		assertTrue(success, "Delete should return true");
	}

	List<Employee> buildEmployeesList() {
		List<Employee> employees = new ArrayList<>();

		LocalDate hireDate = LocalDate.parse("1980-12-17");
		employees.add(new Employee(7369, "HEYES", "ANALYST", 7934, hireDate, new BigDecimal("500.00"), new BigDecimal("2"), 10));
		
		hireDate = LocalDate.parse("1982-01-23");
		employees.add(new Employee(7934, "MILLER", "CLERK", 7782, hireDate, new BigDecimal("1300.00"), null, 10));

		return employees;
	}
}
