package com.fidelity.integration;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fidelity.model.PhoneContract;

public class PhoneContractDaoImpl implements PhoneContractDao {
	private final Logger logger = LoggerFactory.getLogger(PhoneContractDaoImpl.class);

	private DataSource datasource;
	
	public PhoneContractDaoImpl(DataSource datasource) {
		this.datasource = datasource;
	}
	
	private final String fullSQL = "SELECT pc.pcid, pc.pcname, " +
			"coalesce(r.ratesname,'N/A') r_name," +
			"coalesce(h.hours_quantity,0) h_quantity," + 
			"coalesce(h.hours_quantity,0)* coalesce(r.ratesprice,0.0) value " + 
			"FROM b_phonecontracts pc " + 
			"LEFT OUTER JOIN b_hours h " + 
			"ON h.pcid = pc.pcid " + 
			"LEFT OUTER JOIN b_rates r " + 
			"ON h.ratesid = r.ratesid " + 
			"ORDER BY pc.pcname ";
	
	private final String pcByIdSQL = "SELECT pc.pcid, pc.pcname, " +
			"coalesce(r.ratesname,'N/A') r_name," +
			"coalesce(h.hours_quantity,0) h_quantity," + 
			"coalesce(h.hours_quantity,0)* coalesce(r.ratesprice,0.0) value " + 
			"FROM b_phonecontracts pc " + 
			"LEFT OUTER JOIN b_hours h " + 
			"ON h.pcid = pc.pcid " + 
			"LEFT OUTER JOIN b_rates r " + 
			"ON h.ratesid = r.ratesid " +
			"WHERE pc.pcid = ? " +
			"ORDER BY pc.pcname ";
	
	@Override
	public List<PhoneContract> getFullPhoneContracts() {
		 
		List<PhoneContract> details = null;

		try (Connection conn = datasource.getConnection();
				PreparedStatement stmt = conn.prepareStatement(fullSQL)) {
			ResultSet rs = stmt.executeQuery();
			details = handleResults(rs);		
		} catch (SQLException e) {
			logger.error("Cannot execute getFullPhoneContracts", e);
			throw new DatabaseException("Cannot execute getFullPhoneContracts", e);
		}
		return details;
	}

	private List<PhoneContract> handleResults(ResultSet rs) throws SQLException {
		List<PhoneContract> details = new ArrayList<>();
		while (rs.next()) {
			int pcId = rs.getInt("pcid");
			String pcName = rs.getString("pcname");
			String rateName = rs.getString("r_name");
			int quantity = rs.getInt("h_quantity");
			BigDecimal totalValue = rs.getBigDecimal("value");
			PhoneContract detail = new PhoneContract(pcId, pcName, rateName,
							quantity, totalValue);
			details.add(detail);
		}
		return details;
	}

	@Override
	public List<PhoneContract> getPhoneContractByID(int pcId) {

		List<PhoneContract> details = null;

		try (Connection conn = datasource.getConnection();
				PreparedStatement stmt = conn.prepareStatement(pcByIdSQL)) {
			stmt.setInt(1, pcId);
			ResultSet rs = stmt.executeQuery();
			details = handleResults(rs);		
		} catch (SQLException e) {
			logger.error("Cannot execute getPhoneContractByID", e);
			throw new DatabaseException("Cannot execute getPhoneContractByID", e);
		}
		return details;
	}


}
