package com.fidelity.integration;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.jdbc.JdbcTestUtils.countRowsInTable;

import java.math.BigDecimal;
import java.sql.Connection;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.jdbc.core.JdbcTemplate;

import com.fidelity.model.PhoneContract;

class PhoneContractDaoImplTest {
	PhoneContractDaoImpl dao;
	private SimpleDataSource dataSource;

	
	PhoneContract pc1;
	PhoneContract pc2;
	PhoneContract pc3;
	
//	1,"Cheap USA","weekend",2,0.84
//	1,"Cheap USA","night",1,0.04
//	3,"Global","workhours",1,4.2
//	3,"Global","flat",1,4.42
//	2,"North America","flat",42,185.64
//	2,"North America","weekend",1,0.42
//	4,"Village","N/A",0,0
	

	@BeforeEach
	void setUp() throws Exception {
		dataSource = new SimpleDataSource();
		dao = new PhoneContractDaoImpl(dataSource);
		
		pc1 = new PhoneContract(1,"Cheap USA","weekend",2, new BigDecimal("0.84"));
		pc2 = new PhoneContract(3,"Global","flat",1, new BigDecimal("4.42"));
		pc3 = new PhoneContract(4,"Village","N/A",0, new BigDecimal("0"));
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	void testLoadAllPhoneContractsSize() {
		List<PhoneContract> details = dao.getFullPhoneContracts();
		assertNotNull(details);
		assertEquals(7, details.size());	
	}
	
	@Test
	void testListContainsPhoneContracts() {
		List<PhoneContract> details = dao.getFullPhoneContracts();
		assertNotNull(details);
		assertTrue(details.contains(pc1));	
		assertTrue(details.contains(pc2));	
		assertTrue(details.contains(pc3));	
		assertTrue(details.get(0).equals(pc1)); // checking for location in array
	}

	@Test
	void testSinglePhoneContract() {
		List<PhoneContract> details = dao.getPhoneContractByID(1);
		assertNotNull(details);
		assertTrue(details.contains(pc1));	
		assertTrue(details.get(1).equals(pc1)); // checking for location in array
	}

	@Test
	void testSinglePhoneContractSize() {
		List<PhoneContract> details = dao.getPhoneContractByID(1);
		assertNotNull(details);
		int expected =2;
		assertEquals(expected, details.size());
	}
	
	@Test
	void testInvalidSinglePhoneContract() {
		List<PhoneContract> details = dao.getPhoneContractByID(-1);
		assertNotNull(details);
		int expected = 0;
		assertEquals(expected, details.size());
	}

}
