package com.fidelity.services;

import java.math.BigDecimal;
import java.util.List;

import com.fidelity.integration.EmployeeDao;
import com.fidelity.model.Employee;

public class EmployeeManagementService {
	private EmployeeDao dao;
	
	public EmployeeManagementService(EmployeeDao dao) {
		this.dao = dao;
	}

	public Employee insertNewManager(Employee manager, List<Employee> employees) {
		Employee newManager = null;
		
		newManager = dao.insertEmployee(manager);
		int managerId = manager.getEmpNumber();
		
		for (Employee employee : employees) {
			employee.setMgrNumber(managerId);
			dao.updateEmployee(employee);
		}
		
		return newManager;
	}
	
	public List<Employee> queryAllEmployees() {
		return dao.queryAllEmployees();
	}

	public Employee queryEmployeeById(int id) {
		return dao.queryEmployeeById(id);
	}

	public Employee insertEmployee(Employee employee) {
		return dao.insertEmployee(employee);
	}

	public Employee updateEmployee(Employee employee) {
		return dao.updateEmployee(employee);
	}

	public boolean deleteEmployee(int id) {
		return dao.deleteEmployee(id);
	}
	
	public BigDecimal queryTotalSalary() {
		List<Employee> employees = dao.queryAllEmployees();
		BigDecimal totalSalary = BigDecimal.ZERO;
		
		for (Employee employee : employees) {
			totalSalary = totalSalary.add(employee.getSalary());
		}
		
		return totalSalary;
	}



}
