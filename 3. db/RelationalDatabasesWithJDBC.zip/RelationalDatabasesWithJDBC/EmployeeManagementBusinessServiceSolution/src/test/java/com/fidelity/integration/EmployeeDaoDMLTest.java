package com.fidelity.integration;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.SQLException;
import java.time.LocalDate;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.jdbc.core.JdbcTemplate;
import static org.springframework.test.jdbc.JdbcTestUtils.countRowsInTable;
import static org.junit.Assert.assertThrows;
import static org.junit.jupiter.api.Assertions.*;

import com.fidelity.model.Employee;

class EmployeeDaoDMLTest {
	JdbcTemplate jdbcTemplate;
	DbTestUtils dbTestUtils;
	EmployeeDao dao;
	SimpleDataSource dataSource;
	Connection connection;
	TransactionManager transactionManager;

	Employee emp7369;
	Employee emp7934;
	  
	@BeforeEach
	void setUp() throws SQLException {
		dataSource = new SimpleDataSource();
		connection = dataSource.getConnection();
		transactionManager = new TransactionManager(dataSource);
		
		transactionManager.startTransaction();
		
		dbTestUtils = new DbTestUtils(connection);		
		jdbcTemplate = dbTestUtils.initJdbcTemplate();
		
		dao = new EmployeeDaoOracleImpl(dataSource);
		
		// Note format of date depends on query and/or database parameters
		// NULL commission handled correctly
		LocalDate hireDate = LocalDate.parse("1980-12-17");
		emp7369 = new Employee(7369, "SMITH", "CLERK", 7902, hireDate, new BigDecimal("800.00"), null, 20);
		emp7934 = new Employee(7934, "MILLER", "CLERK", 7782, hireDate, new BigDecimal("1300.00"), null, 10);
	}

	@AfterEach
	void tearDown() throws SQLException {
		transactionManager.rollbackTransaction();
		dataSource.shutdown();
	}

	/***** DML Tests *****/
	@Test
	void testInsertEmployee() throws SQLException {
		int oldSize = countRowsInTable(jdbcTemplate, "emp");
		
		String empQuery = "select * from emp where empno = 8000";
		assertEquals(0, jdbcTemplate.queryForList(empQuery).size(), "Should not contain new values before insert");
		
		LocalDate hireDate = LocalDate.parse("1980-12-17");
		Employee new8000 = new Employee(8000, "HEYES", "ANALYST", 7934, hireDate, new BigDecimal("500.00"), new BigDecimal("2"), 10);
		Employee employee = dao.insertEmployee(new8000);

		assertEquals(new8000, employee, "Returned Employee should equal inserted Employee");
		int newSize = countRowsInTable(jdbcTemplate, "emp");
		assertEquals(oldSize + 1, newSize, "Should have one more employee after insert");
		
		assertEquals(1, jdbcTemplate.queryForList(empQuery).size(), "Should contain new values after insert");
	}
	
	@Test
	void testInsertEmployeeThrowsException() throws SQLException {
		int duplicatePrimaryKey = 7369;
		LocalDate hireDate = LocalDate.parse("1980-12-17");

		assertThrows(DatabaseException.class, () -> {
			Employee upd7369 = new Employee(duplicatePrimaryKey, "HEYES", "ANALYST", 7934, hireDate,
					new BigDecimal("500.00"), new BigDecimal("2"), 10);
			dao.insertEmployee(upd7369);
		});
	}

	@Test
	void testUpdateEmployee() throws SQLException {
		int oldSize = countRowsInTable(jdbcTemplate, "emp");
		
		String empQuery = "select * from emp where empno = 7369 and ename = 'HEYES'";
		assertEquals(0, jdbcTemplate.queryForList(empQuery).size(), "Should not contain new values before update");
		
		LocalDate hireDate = LocalDate.parse("1980-12-17");
		Employee upd7369 = new Employee(7369, "HEYES", "ANALYST", 7934, hireDate, new BigDecimal("500.00"), new BigDecimal("2"), 10);
		Employee employee = dao.updateEmployee(upd7369);

		assertEquals(upd7369, employee, "Returned Employee should equal the updated Employee");
		
		int newSize = countRowsInTable(jdbcTemplate, "emp");
		assertEquals(oldSize, newSize, "Should have same number of employees after update");
	}

	@Test
	void testUpdateEmployeeThrowsException() throws SQLException {
		int invalidDepartmentId = 42;
		LocalDate hireDate = LocalDate.parse("1980-12-17");

		assertThrows(DatabaseException.class, () -> {
			Employee upd7369 = new Employee(7369, "HEYES", "ANALYST", 7934, hireDate, new BigDecimal("500.00"),
					new BigDecimal("2"), invalidDepartmentId);
			dao.updateEmployee(upd7369);
		});
	}

	@Test
	void testDeleteEmployee() throws SQLException {
		int oldSize = countRowsInTable(jdbcTemplate, "emp");

		// delete an employee
		int id = 7369;
		boolean success = dao.deleteEmployee(id);
		
		assertTrue(success, "Delete should return true");
		
		int newSize = countRowsInTable(jdbcTemplate, "emp");
		assertEquals(oldSize - 1, newSize, "Should have one less employee after delete");
	}
	

	/***** Utility Methods *****/
	private void beginTransaction() throws SQLException {
		connection.setAutoCommit(false);
	}
	
	private void rollbackTransaction() throws SQLException {
		connection.rollback();	
	}
}
