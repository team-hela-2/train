package com.fidelity.integration;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import com.fidelity.model.Employee;

class EmployeeDaoQueryTest {
	EmployeeDao dao;
	SimpleDataSource dataSource;
	
	Employee emp7369;
	Employee emp7934;
	  
	@BeforeEach
	void setUp() throws SQLException {
		dataSource = new SimpleDataSource();
		
		dao = new EmployeeDaoOracleImpl(dataSource);
		
		// Note format of date depends on query and/or database parameters
		// NULL commission handled correctly
		LocalDate hireDate = LocalDate.parse("1980-12-17");
		emp7369 = new Employee(7369, "SMITH", "CLERK", 7902, hireDate, new BigDecimal("800.00"), null, 20);
		
		hireDate = LocalDate.parse("1982-01-23");
		emp7934 = new Employee(7934, "MILLER", "CLERK", 7782, hireDate, new BigDecimal("1300.00"), null, 10);
	}

	@AfterEach
	void tearDown() throws SQLException {
		dataSource.shutdown();
	}

	/***** Query Tests *****/
	@Test
	void testQueryAllEmployees() {
		List<Employee> emps = dao.queryAllEmployees();
		assertEquals(14, emps.size(), "Should be 14 records");
		assertTrue(emps.contains(emp7369), "Should contain SMITH 7369");
		assertTrue(emps.contains(emp7934), "Should contain MILLER 7934");
	}
		
	@Test
	void testQueryEmployeeByNumber7369() {
		int id = 7369;
		Employee emp = dao.queryEmployeeById(id);
		assertEquals(id, emp.getEmpNumber());
	}
	
	@Test
	void testQueryEmployeeByNumber8000() {
		int id = 8000;
		Employee emp = dao.queryEmployeeById(id);
		assertNull(emp);
	}

	@ParameterizedTest
	@ValueSource(strings = { "SMITH", "MILLER" })
	void testQueryEmployeeByName(String name) {
		List<Employee> employees = dao.queryEmployeeByName(name);
		assertNotNull(employees);
		for (Employee employee : employees) {
			assertEquals(employee.getEmpName(), name);
		}
	}
	
	@Test 
	void testNoSqlInjection() {
		String name = "BobbyTables' OR '1' = '1";
		List<Employee> employees = dao.queryEmployeeByName(name);
		assertEquals(employees.size(), 0);		
	}

	@ParameterizedTest
	@ValueSource(ints = { 10, 20 })
	void testQueryEmployeeByDepartment(int departmentId) {
		List<Employee> employees = dao.queryEmployeeByDepartment(departmentId);
		assertNotNull(employees);
		for (Employee employee : employees) {
			assertEquals(employee.getDeptNumber(), departmentId);
		}
	}

	@ParameterizedTest
	@ValueSource(ints = {7369, 7499, 7839})
	void testQueryEmployeeById(int id) {
		Employee emp = dao.queryEmployeeById(id);
		assertEquals(id, emp.getEmpNumber());
	}

	@ParameterizedTest
	@ValueSource(ints = {8000, 4242, 2001, 999})
	void testQueryEmployeeByInvalidId(int id) {
		Employee emp = dao.queryEmployeeById(id);
		assertNull(emp);
	}
	
}
