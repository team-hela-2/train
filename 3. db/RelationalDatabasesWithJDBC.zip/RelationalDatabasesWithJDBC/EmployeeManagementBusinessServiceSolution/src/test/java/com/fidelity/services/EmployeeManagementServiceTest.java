package com.fidelity.services;

import static org.junit.jupiter.api.Assertions.*;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import com.fidelity.integration.EmployeeDao;
import com.fidelity.model.Department;
import com.fidelity.model.Employee;

class EmployeeManagementServiceTest {
	EmployeeManagementService service;
	EmployeeDao dao;
	
	@BeforeEach
	void setUp() throws Exception {
		dao = new MockDao(null);
		service = new EmployeeManagementService(dao);
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	void testServiceCreated() {
		assertNotNull(service);
	}


	@Test
	void testInsertNewManager() {
		LocalDate hireDate = LocalDate.parse("2021-12-17");
		Employee manager = new Employee(4242, "DILBERT", "MANAGER", 7902, hireDate, new BigDecimal("1200.00"), null, 42);
		List<Employee> employees = new ArrayList<>();
		
		employees.add(new Employee(7369, "SMITH", "CLERK", 7902, hireDate, new BigDecimal("800.00"), null, 20));
		employees.add(new Employee(7934, "MILLER", "CLERK", 7782, hireDate, new BigDecimal("1300.00"), null, 10));
		
		Employee newManager = service.insertNewManager(manager, employees);
		
		assertEquals(newManager, manager);
	}

	/***** Query Tests *****/
	@Test
	void testQueryAllEmployees() {
		List<Employee> emps = service.queryAllEmployees();
		assertEquals(2, emps.size(), "Should be 2 records");
	}

	@Test
	void testQueryEmployeeByNumber7369() {
		int id = 7369;
		Employee emp = service.queryEmployeeById(id);
		assertEquals(id, emp.getEmpNumber());
	}

	@ParameterizedTest
	@ValueSource(ints = {7369, 7934})
	void testQueryEmployeeById(int id) {
		Employee emp = service.queryEmployeeById(id);
		assertEquals(id, emp.getEmpNumber());
	}

	@Test
	void testQueryTotalSalary() {
		BigDecimal expected = new BigDecimal ("2100");
		BigDecimal actual = service.queryTotalSalary();
		
		assertEquals(actual.compareTo(expected), 0);
	}
	
	/***** DML Tests *****/
	@Test
	void testInsertEmployee() throws SQLException {
		LocalDate hireDate = LocalDate.parse("1980-12-17");
		Employee new8000 = new Employee(8000, "HEYES", "ANALYST", 7934, hireDate, new BigDecimal("500.00"), new BigDecimal("2"), 10);
		Employee employee = service.insertEmployee(new8000);

		assertEquals(new8000, employee, "Returned Employee should equal inserted Employee");
	}
	
	@Test
	void testUpdateEmployee() throws SQLException {
		LocalDate hireDate = LocalDate.parse("1980-12-17");
		Employee upd7369 = new Employee(7369, "HEYES", "ANALYST", 7934, hireDate, new BigDecimal("500.00"), new BigDecimal("2"), 10);
		Employee employee = service.updateEmployee(upd7369);
		
		assertEquals(upd7369, employee, "Returned Employee should equal the updated Employee");		
	}
	
	@Test
	void testDeleteEmployee() throws SQLException {
		// delete an employee
		int id = 7369;
		boolean success = service.deleteEmployee(id);
		
		assertTrue(success, "Delete should return true");
	}

}

class MockDao extends EmployeeDao {
	List<Employee> employees;
	
	MockDao(DataSource ds) {
		super(ds);
		employees = new ArrayList<>();
		
		LocalDate hireDate = LocalDate.parse("1980-12-17");
		employees.add(new Employee(7369, "SMITH", "CLERK", 7902, hireDate, new BigDecimal("800.00"), null, 20));
		employees.add(new Employee(7934, "MILLER", "CLERK", 7782, hireDate, new BigDecimal("1300.00"), null, 10));
	}
	
	@Override
	public List<Employee> queryAllEmployees() {
		return employees;
	}

	@Override
	public Employee queryEmployeeById(int empNo) {
		Employee employee = null;
		
		for (Employee emp : employees) {
			if (emp.getEmpNumber() == empNo) {
				employee = emp;
				break;
			}
		}
		return employee;
	}

	@Override
	public Employee insertEmployee(Employee employee) {
		return employee;
	}

	@Override
	public Employee updateEmployee(Employee employee) {
		return employee;
	}

	@Override
	public boolean deleteEmployee(int id) {
		return true;
	}

	@Override
	public List<Employee> queryEmployeeByName(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Employee> queryEmployeeByDepartment(int departmentId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Department queryForDepartment(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Department> queryForAllDepartments() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Employee queryEmployeeByIdWithPerformance(int empNo) {
		// TODO Auto-generated method stub
		return null;
	}
}
