package com.fidelity.services;

import java.math.BigDecimal;
import java.util.List;

import com.fidelity.integration.EmployeeDao;
import com.fidelity.model.Employee;

public class EmployeeManagementService {
	private EmployeeDao dao;
	
	public EmployeeManagementService(EmployeeDao dao) {
		this.dao = dao;
	}

	

}
