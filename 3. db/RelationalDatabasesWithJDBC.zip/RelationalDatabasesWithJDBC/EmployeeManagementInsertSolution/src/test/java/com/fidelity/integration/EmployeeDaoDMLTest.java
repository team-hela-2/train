package com.fidelity.integration;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.SQLException;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.jdbc.core.JdbcTemplate;
import static org.springframework.test.jdbc.JdbcTestUtils.countRowsInTable;
import static org.junit.jupiter.api.Assertions.*;

import com.fidelity.model.Employee;

class EmployeeDaoDMLTest {
	JdbcTemplate jdbcTemplate;
	DbTestUtils dbTestUtils;
	EmployeeDao dao;
	SimpleDataSource dataSource;
	Connection connection;
	
	Employee emp7369;
	Employee emp7934;
	  
	@BeforeEach
	void setUp() throws SQLException {
		dataSource = new SimpleDataSource();
		connection = dataSource.getConnection();
		
		beginTransaction();
		
		dbTestUtils = new DbTestUtils(connection);		
		jdbcTemplate = dbTestUtils.initJdbcTemplate();
		
		dao = new EmployeeDaoOracleImpl(dataSource);
		
		// Note format of date depends on query and/or database parameters
		// NULL commission handled correctly
		emp7369 = new Employee(7369, "SMITH", "CLERK", 7902, "17-DEC-1980", new BigDecimal("800.00"), null, 20);
		emp7934 = new Employee(7934, "MILLER", "CLERK", 7782, "23-JAN-1982", new BigDecimal("1300.00"), null, 10);
	}

	@AfterEach
	void tearDown() throws SQLException {
		rollbackTransaction();
		dataSource.shutdown();
	}

	/***** DML Tests *****/
	@Test
	void testInsertEmployee() throws SQLException {
		int oldSize = countRowsInTable(jdbcTemplate, "emp");
		
		String empQuery = "select * from emp where empno = 8000";
		assertEquals(0, jdbcTemplate.queryForList(empQuery).size(), "Should not contain new values before insert");
		
		Employee new8000 = new Employee(8000, "HEYES", "ANALYST", 7934, "18-JAN-1981", new BigDecimal("500.00"), new BigDecimal("2"), 10);
		Employee employee = dao.insertEmployee(new8000);

		assertEquals(new8000, employee, "Returned Employee should equal inserted Employee");
		int newSize = countRowsInTable(jdbcTemplate, "emp");
		assertEquals(oldSize + 1, newSize, "Should have one more employee after insert");
		
		assertEquals(1, jdbcTemplate.queryForList(empQuery).size(), "Should contain new values after insert");

		dbTestUtils.assertEmployeeEquals(new8000, jdbcTemplate.queryForMap(empQuery));		
	}
	

	/***** Utility Methods *****/
	private void beginTransaction() throws SQLException {
		connection.setAutoCommit(false);
	}
	
	private void rollbackTransaction() throws SQLException {
		connection.rollback();	
	}
}
