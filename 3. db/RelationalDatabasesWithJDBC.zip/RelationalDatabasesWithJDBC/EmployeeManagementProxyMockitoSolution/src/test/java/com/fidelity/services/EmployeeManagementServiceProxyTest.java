package com.fidelity.services;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InOrder;
import org.mockito.Mockito;

import com.fidelity.integration.TransactionManager;
import com.fidelity.model.Employee;

import static org.mockito.Mockito.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

class EmployeeManagementServiceProxyTest {
	EmployeeManagementServiceProxy proxy;
	EmployeeManagementService mockService;
	TransactionManager mockManager;
	
	@BeforeEach
	void setUp() throws Exception {
		mockService = mock(EmployeeManagementService.class);
		mockManager = mock(TransactionManager.class);
				
		proxy = new EmployeeManagementServiceProxy(mockService, mockManager);
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	void testProxyCreated() {
		assertNotNull(proxy);
	}
	
	@Test
	void testInsertNewManager() {
		LocalDate hireDate = LocalDate.parse("2021-12-17");
		Employee manager = new Employee(4242, "DILBERT", "MANAGER", 7902, hireDate, new BigDecimal("1200.00"), null, 42);
		List<Employee> employees = new ArrayList<>();		
		employees.add(new Employee(7369, "SMITH", "CLERK", 7902, hireDate, new BigDecimal("800.00"), null, 20));
		employees.add(new Employee(7934, "MILLER", "CLERK", 7782, hireDate, new BigDecimal("1300.00"), null, 10));
		
		proxy.insertNewManager(manager, employees);
		
		InOrder inOrder = Mockito.inOrder(mockManager, mockService);
		inOrder.verify(mockManager).startTransaction();
		inOrder.verify(mockService).insertNewManager(manager, employees);
		inOrder.verify(mockManager).commitTransaction();
	}
	
	@Test
	void testQueryTotalSalary() {	
		proxy.queryTotalSalary();

		verify(mockService).queryTotalSalary();
	}

	@Test
	void testQueryAllEmployees() {
		proxy.queryAllEmployees();
		
		verify(mockService).queryAllEmployees();		
	}

	@Test
	void testQueryEmployeeById() {
		int id = 42;
		proxy.queryEmployeeById(id);
		
		verify(mockService).queryEmployeeById(id);		
	}

	@Test
	void testInsertEmployee() {
		int id = 8000;
		LocalDate hireDate = LocalDate.parse("1981-01-18");
		Employee emp8000 = new Employee(id, "HEYES", "ANALYST", 7934, hireDate, new BigDecimal("500.00"), new BigDecimal("2"), 10);
		
		proxy.insertEmployee(emp8000);
		
		verify(mockManager).startTransaction();
		verify(mockService).insertEmployee(emp8000);
		verify(mockManager).commitTransaction();
		
		InOrder inOrder = Mockito.inOrder(mockManager);
		inOrder.verify(mockManager).startTransaction();
		inOrder.verify(mockManager).commitTransaction();
	}

	@Test
	void testUpdateEmployee() {
		int id = 7369;
		LocalDate hireDate = LocalDate.parse("1980-12-17");
		Employee emp7369 = new Employee(id, "SMITH", "CLERK", 7902, hireDate, new BigDecimal("800.00"), null, 20);
		
		proxy.updateEmployee(emp7369);
		
		verify(mockManager).startTransaction();
		verify(mockService).updateEmployee(emp7369);
		verify(mockManager).commitTransaction();
		
		InOrder inOrder = Mockito.inOrder(mockManager);
		inOrder.verify(mockManager).startTransaction();
		inOrder.verify(mockManager).commitTransaction();

	}

	@Test
	void testDeleteEmployee() {
		int id = 42;
		
		proxy.deleteEmployee(id);
		
		verify(mockManager).startTransaction();
		verify(mockService).deleteEmployee(id);
		verify(mockManager).commitTransaction();
		
		InOrder inOrder = Mockito.inOrder(mockManager);
		inOrder.verify(mockManager).startTransaction();
		inOrder.verify(mockManager).commitTransaction();

	}

}
