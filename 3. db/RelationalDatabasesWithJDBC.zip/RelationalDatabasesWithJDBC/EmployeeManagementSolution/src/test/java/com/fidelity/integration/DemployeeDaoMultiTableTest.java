package com.fidelity.integration;

import static org.junit.jupiter.api.Assertions.*;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.fidelity.model.Department;
import com.fidelity.model.Employee;

class DemployeeDaoMultiTableTest {
	EmployeeDao dao;
	SimpleDataSource dataSource;
	
	Employee emp7369;
	Employee emp7934;
	  
	@BeforeEach
	void setUp() throws SQLException {
		dataSource = new SimpleDataSource();		
		dao = new EmployeeDaoOracleImpl(dataSource);		
	}

	@AfterEach
	void tearDown() throws SQLException {
		dataSource.shutdown();
	}
	
	@Test
	void testQueryForDepartment() {
		int id = 10;
		Department department = dao.queryForDepartment(id);
		
		assertNotNull(department);
		assertEquals(id, department.getId());
		for (Employee employee : department.getEmployees()) {
			assertEquals(id, employee.getDeptNumber());
		}
	}
	
	@Test
	void testQueryAllDepartments() {
		List<Department> departments = dao.queryForAllDepartments();
		
		assertNotNull(departments);
		assertEquals(4, departments.size());
	}
}
