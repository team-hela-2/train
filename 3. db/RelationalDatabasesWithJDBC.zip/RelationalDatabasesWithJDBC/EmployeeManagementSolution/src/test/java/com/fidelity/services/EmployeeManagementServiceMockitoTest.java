package com.fidelity.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import com.fidelity.integration.DatabaseException;
import com.fidelity.integration.EmployeeDao;
import com.fidelity.model.Employee;

/*
 * Copy the following dependency to your pom.xml in the <dependencies> section:
		<dependency>
			<groupId>org.mockito</groupId>
			<artifactId>mockito-junit-jupiter</artifactId>
			<version>4.7.0</version>
			<scope>test</scope>
		</dependency>
 */
class EmployeeManagementServiceMockitoTest {
	EmployeeManagementService service;
	EmployeeDao dao;
	
	Employee emp7369 = new Employee(7369, "SMITH", "CLERK", 7902, LocalDate.of(1980, 12, 17), 
									new BigDecimal("800.00"), null, 20);
	Employee emp7934 = new Employee(7934, "MILLER", "CLERK", 7782, LocalDate.of(1980, 12, 17), 
									new BigDecimal("1300.00"), null, 10);
	List<Employee> mockEmps = List.of(emp7369, emp7934);

	@BeforeEach
	void setUp() throws Exception {
		// create a mock DAO object
		dao = Mockito.mock(EmployeeDao.class);
		// assign the mock DAO to the object under test
		service = new EmployeeManagementService(dao);
	}

	/***** Query Tests *****/
	@Test
	void testQueryAllEmployees() {
		// Configure the mock to return the mock employee list 
		// when its queryAllEmployees() method is called
		Mockito.when(dao.queryAllEmployees())
			   .thenReturn(mockEmps);

		List<Employee> emps = service.queryAllEmployees();
		
		assertEquals(2, emps.size(), "Should be 2 records");
	}

	void testQueryEmployeeById_7369() {
		// Configure the mock to return one mock employee 
		// when its queryEmployeeById() method is called
		int id = 7369;
		Mockito.when(dao.queryEmployeeById(id))
			   .thenReturn(emp7369);
		
		Employee emp = service.queryEmployeeById(id);
		
		assertEquals(id, emp.getEmpNumber());
	}

	@Test
	void testQueryTotalSalary() {
		Mockito.when(dao.queryAllEmployees())
			   .thenReturn(mockEmps);
		BigDecimal expected = new BigDecimal("2100.00");
		
		BigDecimal actual = service.queryTotalSalary();
		
		assertEquals(expected, actual);
	}

	@Test
	void testQueryTotalSalary_EmptyList() {
		Mockito.when(dao.queryAllEmployees())
			   .thenReturn(new ArrayList<>());
		
		BigDecimal actual = service.queryTotalSalary();
		
		assertEquals(BigDecimal.ZERO, actual);
	}
	
	/***** DML Tests *****/
	@Test
	void testInsertEmployee() throws SQLException {
		Employee new8000 = new Employee(8000, "HEYES", "ANALYST", 7934, LocalDate.of(1980, 12, 17), 
										new BigDecimal("500.00"), new BigDecimal("2"), 10);
		
		Mockito.when(dao.insertEmployee(new8000))
			   .thenReturn(new8000);
		
		Employee employee = service.insertEmployee(new8000);

		assertEquals(new8000, employee, "Returned Employee should equal inserted Employee");
	}
	
	@Test
	void testInsertEmployee_Exception() throws SQLException {
		Employee new8000 = new Employee(8000, "HEYES", "ANALYST", 7934, LocalDate.of(1980, 12, 17), 
										new BigDecimal("500.00"), new BigDecimal("2"), 10);
		
		// Configure the mock to throw an exception when its insertEmployee() method is called
		Mockito.when(dao.insertEmployee(new8000))
			   .thenThrow(new DatabaseException());
		
		assertThrows(DatabaseException.class, () -> 
			service.insertEmployee(new8000)
		);
	}
	
	@Test
	void testUpdateEmployee() throws SQLException {
		Employee upd7369 = new Employee(7369, "HEYES", "ANALYST", 7934, LocalDate.of(1980, 12, 17), 
										new BigDecimal("500.00"), new BigDecimal("2"), 10);
		
		Mockito.when(dao.updateEmployee(upd7369))
			   .thenReturn(upd7369);

		Employee employee = service.updateEmployee(upd7369);
		
		assertEquals(upd7369, employee, "Returned Employee should equal the updated Employee");		
	}
	
	@Test
	void testDeleteEmployee() throws SQLException {
		// delete an employee
		int id = 7369;
		Mockito.when(dao.deleteEmployee(id))
			   .thenReturn(true);
		
		boolean success = service.deleteEmployee(id);
		
		assertTrue(success, "Delete should return true");
	}

	@Test
	void testInsertNewManager() {
		Employee manager = new Employee(4242, "DILBERT", "MANAGER", 7902, LocalDate.of(1980, 12, 17), 
										new BigDecimal("1200.00"), null, 42);
		
		// Configure the mock to return the above manager when its insertEmployee() method is called
		Mockito.when(dao.insertEmployee(manager))
			   .thenReturn(manager);
		
		// Call the method under test
		Employee newManager = service.insertNewManager(manager, mockEmps);	
		
		// Verify that the data returned by the DAO method was handled correctly
		assertEquals(newManager, manager);
	}

	@Test
	void testInsertNewManager_Exception() {
		Employee manager = new Employee(4242, "DILBERT", "MANAGER", 7902, LocalDate.of(1980, 12, 17), 
										new BigDecimal("1200.00"), null, 42);
		
		// Configure the mock to throw an exception when its insertEmployee() method is called
		Mockito.when(dao.insertEmployee(manager))
			   .thenThrow(new DatabaseException());
		
		// Call the method under test
		assertThrows(DatabaseException.class, () ->
			service.insertNewManager(manager, mockEmps)
		);
	}
}
