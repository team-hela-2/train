package com.fidelity.services;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.jdbc.JdbcTestUtils.countRowsInTable;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.jdbc.core.JdbcTemplate;

import com.fidelity.integration.DbTestUtils;
import com.fidelity.integration.EmployeeDao;
import com.fidelity.integration.EmployeeDaoOracleImpl;
import com.fidelity.integration.SimpleDataSource;
import com.fidelity.model.Employee;

/*
 * The tests in this file are integration tests, not unit tests.
 * The tests have a striking resemblance to the tests in EmployeeManagementServiceTest.
 * But in these tests, the EmployeeManagementService is using the EmployeeDaoOracleImpl
 * not a MockDao.
 * To prevent modifying the Oracle database, a transaction is started before each test
 * and the transaction is rolled back after each test.
 */
class ServiceDaoIntegrationTest {
	JdbcTemplate jdbcTemplate;
	DbTestUtils dbTestUtils;
	EmployeeManagementService service;
	EmployeeDao dao;
	SimpleDataSource dataSource;
	Connection connection;
	Employee emp7369;
	Employee emp7934;
	
	@BeforeEach
	void setUp() throws Exception {
		dataSource = new SimpleDataSource();
		dao = new EmployeeDaoOracleImpl(dataSource);
		service = new EmployeeManagementService(dao);
		
		connection = dataSource.getConnection();
		connection.setAutoCommit(false);
		
		dbTestUtils = new DbTestUtils(connection);		
		jdbcTemplate = dbTestUtils.initJdbcTemplate();

		LocalDate hireDate = LocalDate.parse("1980-12-17");
		emp7369 = new Employee(7369, "SMITH", "CLERK", 7902, hireDate, new BigDecimal("800.00"), null, 20);
		hireDate = LocalDate.parse("1982-01-23");
		emp7934 = new Employee(7934, "MILLER", "CLERK", 7782, hireDate, new BigDecimal("1300.00"), null, 10);
	}

	@AfterEach
	void tearDown() throws Exception {
		connection.rollback();
		dataSource.shutdown();
	}

	@Test
	void testServiceCreated() {
		assertNotNull(service);
	}

	@Test
	void testInsertNewManager() {
		LocalDate hireDate = LocalDate.parse("2021-12-17");
		int departmentId = 10;
		int managerId = 42;
		Employee manager = new Employee(managerId, "DILBERT", "MANAGER", 7902, hireDate, new BigDecimal("1200.00"), null, departmentId);
		List<Employee> employees = new ArrayList<>();
		
		employees.add(new Employee(7369, "SMITH", "CLERK", 7902, hireDate, new BigDecimal("800.00"), null, 20));
		employees.add(new Employee(7934, "MILLER", "CLERK", 7782, hireDate, new BigDecimal("1300.00"), null, 30));
		
		int oldSize = countRowsInTable(jdbcTemplate, "emp");
		
		String empQuery = "select * from emp where empno = " + managerId;
		assertEquals(0, jdbcTemplate.queryForList(empQuery).size(), "Should not contain new manager before insert");
		
		Employee newManager = service.insertNewManager(manager, employees);
		
		assertEquals(newManager, manager);
		assertEquals(1, jdbcTemplate.queryForList(empQuery).size(), "Should contain new manager after insert");

		int newSize = countRowsInTable(jdbcTemplate, "emp");
		assertEquals(newSize, oldSize + 1);
		
		empQuery = "select * from emp where mgr = " + managerId;
		assertEquals(employees.size(), jdbcTemplate.queryForList(empQuery).size(), "Employees should be updated");
	}

	/***** Query Tests *****/
	@Test
	void testQueryAllEmployees() {
		List<Employee> emps = service.queryAllEmployees();
		assertEquals(14, emps.size(), "Should be 14 records");
		assertTrue(emps.contains(emp7369), "Should contain SMITH 7369");
		assertTrue(emps.contains(emp7934), "Should contain MILLER 7934");
	}

	@Test
	void testQueryEmployeeByNumber7369() {
		int id = 7369;
		Employee emp = service.queryEmployeeById(id);
		assertEquals(id, emp.getEmpNumber());
	}
	
	@Test
	void testQueryEmployeeByNumber8000() {
		int id = 8000;
		Employee emp = service.queryEmployeeById(id);
		assertNull(emp);
	}
	
	@ParameterizedTest
	@ValueSource(ints = {7369, 7499, 7839})
	void testQueryEmployeeById(int id) {
		Employee emp = service.queryEmployeeById(id);
		assertEquals(id, emp.getEmpNumber());
	}

	@ParameterizedTest
	@ValueSource(ints = {8000, 4242, 2001, 999})
	void testQueryEmployeeByInvalidId(int id) {
		Employee emp = service.queryEmployeeById(id);
		assertNull(emp);
	}
	

	/***** DML Tests *****/
	@Test
	void testInsertEmployee() throws SQLException {
		int oldSize = countRowsInTable(jdbcTemplate, "emp");
		
		String empQuery = "select * from emp where empno = 8000";
		assertEquals(0, jdbcTemplate.queryForList(empQuery).size(), "Should not contain new values before insert");
		
		LocalDate hireDate = LocalDate.parse("1981-01-18");
		Employee new8000 = new Employee(8000, "HEYES", "ANALYST", 7934, hireDate, new BigDecimal("500.00"), new BigDecimal("2"), 10);
		Employee employee = service.insertEmployee(new8000);

		assertEquals(new8000, employee, "Returned Employee should equal inserted Employee");
		int newSize = countRowsInTable(jdbcTemplate, "emp");
		assertEquals(oldSize + 1, newSize, "Should have one more employee after insert");
		
		assertEquals(1, jdbcTemplate.queryForList(empQuery).size(), "Should contain new values after insert");
	}
	
	@Test
	void testUpdateEmployee() throws SQLException {
		int oldSize = countRowsInTable(jdbcTemplate, "emp");
		
		String empQuery = "select * from emp where empno = 7369 and ename = 'HEYES'";
		assertEquals(0, jdbcTemplate.queryForList(empQuery).size(), "Should not contain new values before update");
		
		LocalDate hireDate = LocalDate.parse("1981-01-18");
		Employee upd7369 = new Employee(7369, "HEYES", "ANALYST", 7934, hireDate, new BigDecimal("500.00"), new BigDecimal("2"), 10);
		Employee employee = service.updateEmployee(upd7369);

		assertEquals(upd7369, employee, "Returned Employee should equal the updated Employee");
		
		int newSize = countRowsInTable(jdbcTemplate, "emp");
		assertEquals(oldSize, newSize, "Should have same number of employees after update");
	}
	
	@Test
	void testDeleteEmployee() throws SQLException {
		int oldSize = countRowsInTable(jdbcTemplate, "emp");

		// delete an employee
		int id = 7369;
		boolean success = service.deleteEmployee(id);
		
		assertTrue(success, "Delete should return true");
		
		int newSize = countRowsInTable(jdbcTemplate, "emp");
		assertEquals(oldSize - 1, newSize, "Should have one less employee after delete");
	}
}
