package com.fidelity.integration;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.SQLException;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.jdbc.core.JdbcTemplate;
import static org.springframework.test.jdbc.JdbcTestUtils.countRowsInTable;
import static org.junit.jupiter.api.Assertions.*;

import com.fidelity.model.Employee;

class EmployeeDaoDMLTest {
	JdbcTemplate jdbcTemplate;
	DbTestUtils dbTestUtils;
	EmployeeDao dao;
	SimpleDataSource dataSource;
	Connection connection;
	
	Employee emp7369;
	Employee emp7934;
	  
	@BeforeEach
	void setUp() throws SQLException {
		dataSource = new SimpleDataSource();
		connection = dataSource.getConnection();
						
		// Start the transaction
		
		
		dbTestUtils = new DbTestUtils(connection);		
		jdbcTemplate = dbTestUtils.initJdbcTemplate();
		
		
		// Note format of date depends on query and/or database parameters
		// NULL commission handled correctly
		emp7369 = new Employee(7369, "SMITH", "CLERK", 7902, "17-DEC-1980", new BigDecimal("800.00"), null, 20);
		emp7934 = new Employee(7934, "MILLER", "CLERK", 7782, "23-JAN-1982", new BigDecimal("1300.00"), null, 10);
	}

	@AfterEach
	void tearDown() throws SQLException {
		// Rollback the transaction
		
		// Shutdown the DataSource
		dataSource.shutdown();
	}


	

	/***** Utility Methods *****/
	private void beginTransaction() throws SQLException {
		connection.setAutoCommit(false);
	}
	
	private void rollbackTransaction() throws SQLException {
		connection.rollback();	
	}
}
