SELECT 123.45
     , ROUND(123.45)    AS A1
     , ROUND(123.45,1)  AS B1 
     , ROUND(123.45,2)  AS C1
     , ROUND(123.45,-1) AS D1
     , ROUND(123.45,-2) AS E1  
FROM   DUAL;

SELECT 123.55
     , ROUND(123.55)    AS A2
     , ROUND(123.55,1)  AS B2
     , ROUND(123.55,2)  AS C2
     , ROUND(123.55,-1) AS D2
     , ROUND(123.55,-2) AS E2
FROM   DUAL;

SELECT 123.55
     , TRUNC(123.55)    AS A
     , TRUNC(123.55,1)  AS B
     , TRUNC(123.55,2)  AS C
     , TRUNC(123.55,-1) AS D
     , TRUNC(123.55,-2) AS E
FROM   DUAL;

SELECT first_name || ' ' || last_name || ' was hired on ' || hire_date
FROM   employees 
WHERE  employee_id IN (163,164);

SELECT LOWER(first_name) || ' ' || UPPER(last_name) || ' was hired on ' || hire_date
FROM   employees 
WHERE  employee_id IN (163,164);

SELECT  hire_date 
FROM    employees 
WHERE   last_name = 'GREENE';

SELECT  hire_date 
FROM    employees 
WHERE   UPPER(last_name) = 'GREENE';

SELECT country_name
     , SUBSTR(country_name,1,2)    AS A
     , SUBSTR(country_name,1)      AS B
     , SUBSTR(country_name,5,3)    AS C
     , SUBSTR(country_name,-10,3)  AS D
     , SUBSTR(country_name,-4)     AS E
FROM   countries 
WHERE  country_id = 'CH';

SELECT job_title 
     , TRIM(BOTH     'M'  FROM job_title) AS A
     , TRIM(LEADING  'M'  FROM job_title) AS B
     , TRIM(TRAILING 'R'  FROM job_title) AS C
     , TRIM(TRAILING 'r'  FROM job_title) AS D
FROM   jobs 
WHERE  job_id = 'MK_MAN';

SELECT job_title 
     , INSTR(job_title,'M',   1, 1) AS A
     , INSTR(job_title,'M',   1, 2) AS B
     , INSTR(job_title,'M',   2, 1) AS C
     , INSTR(job_title,'ark', 1, 1) AS D
     , INSTR(job_title,'ark', 1, 2) AS E
FROM   jobs 
WHERE  job_id = 'MK_MAN';

SELECT employee_id, first_name, last_name
FROM   employees
WHERE  INSTR(last_name,' ') > 1;

SELECT first_name, last_name, email, LENGTH(email) 
FROM   employees 
WHERE  employee_id = 102;

SELECT salary, 
       TO_CHAR(salary,'$99,999')          AS sal, 
       TO_CHAR(hire_date, 'Mon DD, YYYY') AS hired
FROM   employees;
