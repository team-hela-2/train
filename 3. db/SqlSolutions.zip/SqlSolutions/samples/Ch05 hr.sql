SELECT SYSDATE FROM DUAL;

SELECT SYSTIMESTAMP
     , TO_CHAR(SYSTIMESTAMP,'YYYY MM DD HH24 MI SS.FF') 
FROM DUAL;

-- To really illustrate how ADD_MONTHS works, adjust the days (n = 18) so the date 
-- (SYSDATE + n) lands on the last day of a month with 31 days. And adjust the
-- month offsets (m = 1, -6) so the dates ADD_MONTHS(SYSDATE + n, m) land on the last
-- days of 30 day months. This shows that month arithmetic works with whole months
-- regardless of the number of days in the month
SELECT SYSDATE, 
       ADD_MONTHS(SYSDATE,2)        AS A, 
       SYSDATE + 18                 AS B,
       ADD_MONTHS(SYSDATE + 18, 1)  AS C,
       ADD_MONTHS(SYSDATE + 18, -6) AS D 
FROM   DUAL;


SELECT COALESCE(NULL, 2, 3, 4)    AS A,
       COALESCE(1, NULL, 3, 4)    AS B,
       COALESCE(NULL, NULL, 3, 4) AS C
FROM   DUAL;

SELECT commission_pct, last_name, COALESCE(TO_CHAR(commission_pct), 'No Commission')
FROM   employees 
WHERE  employee_id = 100;
