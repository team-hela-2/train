
-- INSERT

INSERT INTO regions 
VALUES (5, 'Antarctica');

INSERT INTO regions (
    region_id, 
    region_name
)
VALUES (
    5,
    'Antarctica'
);

INSERT INTO regions (
    region_name, 
    region_id
)
VALUES (
    'Antarctica', 
    5
);

INSERT INTO regions
VALUES (
    5/1,
    SUBSTR('Antarctica', 1)
);

INSERT INTO regions (
    region_id
) 
VALUES (
    5
);

SELECT * 
FROM   regions 
WHERE  region_id = 5;

-- But, region_name does NOT have a DEFAULT value set, so this will not insert ANYTOWN
INSERT INTO regions (
    region_id, 
    region_name
) 
VALUES (
    5, 
    DEFAULT
);


-- Be careful with this. Hard to undo until you learn about ROLLBACK
INSERT INTO 
       countries (
           country_id, 
           country_name
       )
SELECT SUBSTR(location_id, 1, 2), state_province 
FROM   locations;

SELECT * FROM countries;


-- UPDATE

SELECT * FROM regions;

-- There isn't a region 0, so these will have no effect
UPDATE regions 
SET    region_name = 'NewTown'
WHERE  region_id = 0;

-- Odd SQL this. Will actually fail because there is already a region_id = 1
UPDATE regions 
SET    region_id = 10 - 9
     , region_name = 'SubTown'
WHERE  region_id = 0;

UPDATE regions
SET    region_name = NULL
WHERE  region_id = 0;

UPDATE regions
SET    region_name = 'NULL'
WHERE  region_id = 0;

-- Again, there is no DEFAULT set, so this will not do what the slide says
UPDATE regions
SET   region_name = DEFAULT
WHERE region_id = 0;

UPDATE regions 
SET region_name = (
        SELECT country_name 
        FROM countries
        WHERE country_id = 'AR'
    )
WHERE region_id = 0;

UPDATE regions 
SET (region_id, region_name) = (
        SELECT 10, country_name 
        FROM countries
        WHERE country_id = 'AR'
    )
WHERE region_id = 0;


-- DELETE
-- Better not to execute any of these until you know how to ROLLBACK

DELETE FROM 
       regions 
WHERE  region_id = 12;

DELETE FROM 
       regions;


-- Transactional Control

-- no rows
SELECT job_id, job_title FROM jobs WHERE job_id IN ('IT_AC_PROG', 'IT_PR_PROG');

INSERT INTO jobs VALUES ('IT_AC_PROG', 'Accounting Programmer', 1000, 1000);

SAVEPOINT sp_jobs;

INSERT INTO jobs VALUES ('IT_PR_PROG', 'Payroll Programmer', 999999, 999999);

-- 2 rows
SELECT job_id, job_title FROM jobs WHERE job_id IN ('IT_AC_PROG', 'IT_PR_PROG');

ROLLBACK TO sp_jobs;

-- 1 row
SELECT job_id, job_title FROM jobs WHERE job_id IN ('IT_AC_PROG', 'IT_PR_PROG');

ROLLBACK;

-- no rows
SELECT job_id, job_title FROM jobs WHERE job_id IN ('IT_AC_PROG', 'IT_PR_PROG');



-- Establish read consistency for the transaction
SET TRANSACTION READ ONLY;

-- Create the employee listing by last name
SELECT	*
FROM	employees
ORDER BY last_name;

-- Create the employee listing by hire date
SELECT	*
FROM	employees
ORDER BY hire_date;

-- Release read consistency 
ROLLBACK;
