
-- DELETE
-- Suggest you do not execute any of these until you learn about ROLLBACK

DELETE FROM emp;

-- Contrary to the slide, this does not delete 1 row. Try 3000 instead.
DELETE FROM emp WHERE sal > 6000;

DELETE FROM emp WHERE sal > 1500;

DELETE FROM emp WHERE sal > 10000;
