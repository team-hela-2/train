CREATE OR REPLACE FUNCTION func_get_department_manager(
    parm_department_id IN employees.department_id%TYPE
)
RETURN NUMBER
IS
    dept_count NUMBER(5);
    mgr_id     departments.manager_id%TYPE;
BEGIN
    IF parm_department_id IS NULL THEN
        RAISE_APPLICATION_ERROR(-20001, 'department id may not be NULL');
    END IF;

    SELECT COUNT(*)
    INTO   dept_count
    FROM   departments
    WHERE  department_id = parm_department_id;
    
    -- Here we distinguish between the department not existing
    -- and there being no manager. When we use the function, we
    -- don't make that distinction, so we could simplify this.
    IF dept_count = 0 THEN
        RETURN 0;
    ELSE
        SELECT manager_id
        INTO   mgr_id
        FROM   departments
        WHERE  department_id = parm_department_id;
        
        RETURN mgr_id;
    END IF;
    
    RETURN NULL;
END func_get_department_manager;
/
