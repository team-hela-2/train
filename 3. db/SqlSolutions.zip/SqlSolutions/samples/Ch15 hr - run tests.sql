
SET SERVEROUTPUT ON

BEGIN
    ut.run();
END;
/


BEGIN
    ut.run('test_department_manager');
END;
/


BEGIN
    ut.run('test_department_manager.manager_for_department');
END;
/
