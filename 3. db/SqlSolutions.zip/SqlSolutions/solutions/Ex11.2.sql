
-- 1
SELECT  department_id,
        COUNT(*),
        MIN(salary),
        MAX(salary),
        SUM(salary) AS "Total Salary",
        ROUND(AVG(salary ), 0) AS "Avg Salary"
FROM    employees
GROUP BY
        department_id
-- optional, but achieves same output sequence
ORDER BY
        department_id;

-- 2
SELECT  department_id,
        COUNT(*),
        MIN(salary),
        MAX(salary),
        SUM(salary) AS "Total Salary",
        ROUND(AVG(salary), 0) AS "Avg Salary"
FROM    employees
GROUP BY
        department_id
ORDER BY
        AVG(salary);

-- 3
SELECT  department_id,
        COUNT(*),
        MIN(salary),
        MAX(salary),
        SUM(salary) AS "Total Salary",
        ROUND(AVG(salary), 0) AS "Avg Salary",
        ROUND(AVG(salary) - MIN(salary), 0) AS "Below Avg"
FROM    employees
GROUP BY
        department_id
ORDER BY
        AVG(salary) - MIN(salary) DESC;

-- 4
SELECT  manager_id,
        COUNT(*),
        MIN(salary),
        MAX(salary),
        SUM(salary) AS "Total Salary",
        ROUND(AVG(salary), 0) AS "Avg Salary",
        ROUND(AVG(salary) - MIN(salary), 0) AS "Below Avg"
FROM    employees
GROUP BY
        manager_id
ORDER BY
        AVG(salary) - MIN(salary) DESC;

-- 5
SELECT  department_id AS deptid,
        manager_id AS mgrid,
        COUNT(*),
        MIN(salary),
        MAX(salary),
        SUM(salary) AS "Total Salary",
        ROUND(AVG(salary), 0) AS "Avg Salary",
        ROUND(AVG(salary) - MIN(salary), 0) AS "Below Avg"
FROM    employees
GROUP BY
        department_id, manager_id
ORDER BY
        AVG(salary) - MIN(salary) DESC;


-- 6
SELECT  department_id AS deptid,
        manager_id AS mgrid,
        COUNT(*),
        MIN(salary),
        MAX(salary),
        SUM(salary) AS "Total Salary",
        ROUND(AVG(salary), 0) AS "Avg Salary",
        ROUND(AVG(salary) - MIN(salary), 0) AS "Below Avg"
FROM    employees
GROUP BY
        department_id, manager_id
HAVING  COUNT(*) > 5
ORDER BY
        AVG(salary) - MIN(salary) DESC;
        
-- Bonus

-- 7
SELECT  TRUNC(department_id, -2) AS "Depts by 100s",
        SUM(salary),
        AVG(salary),
        COUNT(*)
FROM    employees
GROUP BY
        TRUNC(department_id, -2)
ORDER BY
        TRUNC(department_id, -2);

-- 8
-- Use two aggregate expressions (GROUP BY only affects the first)
SELECT ROUND(AVG(AVG(salary))) AS "Avg of Dept Avgs"
FROM   employees
GROUP BY
       department_id;

-- Use subquery as source of query (per next section)
SELECT ROUND(AVG("Average")) AS "Avg of Dept Avgs"
FROM   (
           SELECT AVG(salary) AS "Average"
           FROM   employees
           GROUP BY
                  department_id
        );

-- 9
SELECT ROUND(AVG( salary ))
FROM   employees;
