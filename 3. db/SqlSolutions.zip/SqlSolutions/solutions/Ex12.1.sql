
-- 1
SELECT 'Employees who earn commission' AS "Type", 
       COUNT(*) AS "Count"
FROM   employees
WHERE  commission_pct IS NOT NULL
UNION ALL
SELECT 'Employees who do not earn commission',
       COUNT(*)
FROM   employees
WHERE  commission_pct IS NULL;
