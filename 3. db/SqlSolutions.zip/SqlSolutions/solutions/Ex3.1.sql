
-- 1
SELECT first_name,
       last_name,
       TO_CHAR(salary, '$99,999') AS salary
FROM   employees
WHERE  department_id = 30;

-- 2
SELECT first_name,
       last_name,
       TO_CHAR(hire_date, 'YYYY-MM-DD') AS "Date Hired"
FROM   employees
WHERE  department_id = 30;

-- 3
SELECT first_name,
       last_name,
       ROUND(salary, -3) AS RDSAL,
       TRUNC(salary, -3) AS TSAL,
       salary
FROM   employees
WHERE  department_id = 30;

-- 4
SELECT LOWER(first_name) AS LNAME,
       UPPER(last_name) AS UNAME
FROM   employees
WHERE  department_id = 30
ORDER BY
       first_name, last_name;

-- 5
SELECT SUBSTR(first_name, 1, 1) 
        || '. ' 
        || last_name AS NAME
FROM   employees
WHERE  department_id = 30
ORDER BY
       NAME;

-- 6
SELECT street_address,
       LTRIM(street_address, '0123456789 -') AS "Street Name"
FROM   locations
ORDER BY
       "Street Name";

-- Other approaches, using regular expressions (not covered)
SELECT street_address,
       REGEXP_SUBSTR(street_address, '[[:alpha:]].*') 
               AS "Street Name"
FROM   locations
ORDER BY
       "Street Name";

SELECT street_address,
       REGEXP_REPLACE(street_address, '^[-[:digit:] ]*', '')
               AS "Street Name"
FROM   locations
ORDER BY
       "Street Name";

-- 7
SELECT street_address,
       LENGTH(street_address) AS "Street Length"
FROM   locations
ORDER BY
       "Street Length";

-- 8
SELECT location_id, 
       street_address,
       city,
       state_province
FROM   locations
WHERE  INSTR(UPPER(street_address), 'RUE') > 0
OR     INSTR(UPPER(street_address), 'RUA') > 0
ORDER BY
       location_id DESC;

SELECT location_id, 
       street_address,
       city,
       state_province
FROM   locations
WHERE  UPPER(street_address) LIKE '%RUE%'
OR     UPPER(street_address) LIKE '%RUA%'
ORDER BY
       location_id DESC;

-- Using regular expression
SELECT location_id, 
       street_address,
       city,
       state_province
FROM   locations
WHERE  REGEXP_LIKE(street_address, 'RU[AE]', 'i')
ORDER BY
       location_id DESC;

