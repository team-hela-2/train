-- 1
-- using MONTHS_BETWEEN
SELECT department_id,
       first_name,
       last_name,
       hire_date, 
       NVL(commission_pct, 0) AS commission
FROM   employees
WHERE  manager_id = 100
AND    ABS(MONTHS_BETWEEN(hire_date, DATE '2007-01-01'))
               <= 24
ORDER BY
       department_id, hire_date;

-- using BETWEEN
SELECT department_id,
       first_name,
       last_name,
       hire_date, 
       NVL(commission_pct, 0) AS commission
FROM   employees
WHERE  manager_id = 100
AND    hire_date 
         BETWEEN ADD_MONTHS(DATE '2007-01-01', -24)
         AND     ADD_MONTHS(DATE '2007-01-01',  24)
ORDER BY
       department_id, hire_date;

-- 2
SELECT department_id,
       first_name,
       last_name,
       hire_date, 
       COALESCE(commission_pct, 0) AS commission
FROM   employees
WHERE  manager_id = 100
AND    ABS(MONTHS_BETWEEN(hire_date, DATE '2007-01-01'))
               <= 24
ORDER BY
       ABS(MONTHS_BETWEEN(hire_date, DATE '2007-01-01'));

