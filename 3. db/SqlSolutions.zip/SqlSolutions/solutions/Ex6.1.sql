
-- 1  
SELECT *
FROM   regions;

-- 2
INSERT INTO
       regions
       ( region_id, region_name )
VALUES ( 5, 'Central America' );

-- 3
SELECT *
FROM   regions;

-- 4
INSERT INTO
       regions
       ( region_id, region_name )
VALUES ( 6, 'South America' );

-- 5
SELECT *
FROM   regions;

-- 6
UPDATE regions
SET    region_name = 'South and Central America'
WHERE  region_name = 'Central America';

-- 7
SELECT *
FROM   regions;

-- 8
DELETE regions
WHERE  region_id = 6;

-- 9
SELECT *
FROM   regions;

-- 10
ROLLBACK;

SELECT *
FROM   regions;
