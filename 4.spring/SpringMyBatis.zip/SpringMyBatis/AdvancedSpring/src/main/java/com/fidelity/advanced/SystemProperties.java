package com.fidelity.advanced;

public class SystemProperties {

	String country;
	String winDir;

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getWinDir() {
		return winDir;
	}

	public void setWinDir(String winDir) {
		this.winDir = winDir;
	}

}
