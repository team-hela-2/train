package com.fidelity.model;

import java.util.Comparator;
import java.util.List;


public class Library {
	private List<Book> books;
	private Comparator<Book> priceComparator;
	private Comparator<Book> titleComparator;
	
	public Library(List<Book> books) {
		this.books = books;
		
		// TODO: define the price comparator lambda expression
		
		// TODO: define the title comparator lambda expression
	}
	
	public List<Book> sortByPrice(){
		books.sort(priceComparator);
		return books;
	}
	
	public List<Book> sortByTitle() {
		books.sort(titleComparator);
		return books;
	}

	public List<Book> getBooks() {
		return books;
	}

}
