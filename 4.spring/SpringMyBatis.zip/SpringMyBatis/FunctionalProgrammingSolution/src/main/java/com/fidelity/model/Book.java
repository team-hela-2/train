package com.fidelity.model;

public class Book {
	private String isbn;
	private String author;
	private double price;
	private String title;
		
	public Book(String isbn, String author, double price, String title) {
		this.isbn = isbn;
		this.author = author;
		this.price = price;
		this.title = title;
	}
	
	public String getIsbn() {
		return isbn;
	}
	public String getAuthor() {
		return author;
	}
	public double getPrice() {
		return price;
	}
	public String getTitle() {
		return title;
	}

	@Override
	public String toString() {
		return "Book [isbn=" + isbn + ", author=" + author + ", price=" + price + ", title=" + title + "]";
	}
	
	
}
