package com.fidelity.greeter;

import javax.swing.JOptionPane;

public class PopupGreeter implements Greeter {
	private Visitor visitor;

	public PopupGreeter(Visitor visitor) {
		this.visitor = visitor;
	}

	@Override
	public void greet() {
		JOptionPane.showMessageDialog(null, 
						visitor.getGreeting() + ", " + visitor.getName());
	}
}
