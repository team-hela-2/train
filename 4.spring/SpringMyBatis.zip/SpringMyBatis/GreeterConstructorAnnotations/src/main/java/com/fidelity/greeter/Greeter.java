package com.fidelity.greeter;

public interface Greeter {
	public void greet();
}
