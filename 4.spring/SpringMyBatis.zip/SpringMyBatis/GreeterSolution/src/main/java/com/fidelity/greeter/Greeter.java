package com.fidelity.greeter;

public interface Greeter {
	public void greet();
	public void setVisitor(Visitor v);
}