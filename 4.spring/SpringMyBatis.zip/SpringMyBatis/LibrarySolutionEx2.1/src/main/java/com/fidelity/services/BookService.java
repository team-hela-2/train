package com.fidelity.services;

import java.util.ArrayList;
import java.util.List;

import com.fidelity.business.Book;
import com.fidelity.integration.BookDao;

public class BookService {
	private BookDao dao;
	
	public BookService() {
	}
	
	public List<Book> queryAllBooks() {
		List<Book> books = new ArrayList<>();

		books = dao.queryForAllBooks();
		
		return books;
	}

	public void setDao(BookDao dao) {
		this.dao = dao;
	}
	
}
