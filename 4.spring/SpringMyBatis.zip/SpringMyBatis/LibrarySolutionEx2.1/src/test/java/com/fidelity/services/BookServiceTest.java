package com.fidelity.services;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.fidelity.business.Book;

class BookServiceTest {

	private BookService service;
	private AbstractApplicationContext context;
	private String configFile = "library-beans.xml";
	
	private Book firstBook = new Book("Design Patterns", "Gamma, Helm, Johnson, Vlissides", "", 4);
	private Book book2 = new Book("UML Distilled", "Martin Fowler", "", 3); 
	private Book book3 = new Book("Clean Code", "Robert Martin", "", 2); 
	private Book lastBook = new Book("Cryptonomicon", "Neal Stephenson", "", 1); 
	
	private List<Book> expectedBooks = List.of(firstBook, book2, book3, lastBook);

	@BeforeEach
	void setUp() throws Exception {
		context = new ClassPathXmlApplicationContext(configFile);
		service = context.getBean("bookService", BookService.class);
	}
	
	@AfterEach
	void tearDown() {
		context.close();
	}

	@Test
	void testCreateBookService() {
		assertNotNull(service);
	}

	@Test
	void testQueryAllBooks() {
		List<Book> actualBooks = service.queryAllBooks();
		
		assertEquals(expectedBooks, actualBooks);
		
		// if the actual book list is very long, verify the length of the
		// actual list and a few books:
		//   int actualSize = actualBooks.size();
		//   assertEquals(expectedBooks.size(), actualSize);
		//   assertEquals(firstBook, actualBooks.get(0));
		//   assertEquals(lastBook, actualBooks.get(actualSize - 1));
	}

}
