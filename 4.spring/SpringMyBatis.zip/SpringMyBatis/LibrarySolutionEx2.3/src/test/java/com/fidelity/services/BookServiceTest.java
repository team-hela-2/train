package com.fidelity.services;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.fidelity.business.Book;

@ExtendWith(SpringExtension.class)
@ContextConfiguration("classpath:library-beans.xml")
class BookServiceTest {
	@Autowired
	BookService service;

	private Book firstBook = new Book("Design Patterns", "Gamma, Helm, Johnson, Vlissides", "", 4);
	private Book book2 = new Book("UML Distilled", "Martin Fowler", "", 3); 
	private Book book3 = new Book("Clean Code", "Robert Martin", "", 2); 
	private Book lastBook = new Book("Cryptonomicon", "Neal Stephenson", "", 1); 
	
	private List<Book> expectedBooks = List.of(firstBook, book2, book3, lastBook);

	@Test
	void testCreateBookService() {
		assertNotNull(service);
	}

	@Test
	void testQueryAllBooks() {
		List<Book> actualBooks = service.queryAllBooks();
		
		assertEquals(expectedBooks, actualBooks);
	}

}
