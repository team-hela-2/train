package com.fidelity.domain;

public enum ProductType {
	BIG,
	SMALL
}
