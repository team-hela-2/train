package com.fidelity.integration;

import org.slf4j.Logger;
import org.springframework.stereotype.Repository;

@Repository("departmentsDao")
public class DepartmentDaoMyBatisImpl {
	

}
