package com.fidelity.integration;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

class DepartmentDaoMyBatisImplTest {

	/*
	 * Temporary test to check that the mapper is created correctly (MyBatis is configured)
	 * 
	 * TODO: Run this test in Exercise 4.1, but delete it in Exercise 4.2
	 */
	@Test
	void testMapperNotNull() {
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("classpath:beans.xml");
		DepartmentMapper mapper = context.getBean(DepartmentMapper.class);
		assertNotNull(mapper);
		context.close();
	}

}
