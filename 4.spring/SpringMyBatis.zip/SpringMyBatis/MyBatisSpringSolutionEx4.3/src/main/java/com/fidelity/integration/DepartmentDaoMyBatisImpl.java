package com.fidelity.integration;

import java.util.List;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.fidelity.business.Department;

@Repository("departmentsDao")
public class DepartmentDaoMyBatisImpl {
	@Autowired
	private Logger logger;

	@Autowired
	private DepartmentMapper mapper;

	public List<Department> getAllDepartments() {
		logger.debug("enter");
		
		return mapper.getAllDepartments();
	}

	public List<Department> getAllDepartmentsAndEmployees() {
		logger.debug("enter");
		
		return mapper.getAllDepartmentsAndEmployees();
	}

}
