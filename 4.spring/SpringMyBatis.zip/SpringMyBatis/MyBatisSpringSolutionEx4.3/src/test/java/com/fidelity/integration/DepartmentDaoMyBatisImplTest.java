package com.fidelity.integration;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.fidelity.business.Department;
import com.fidelity.business.Employee;

@ExtendWith(SpringExtension.class)
@ContextConfiguration("classpath:beans.xml")
class DepartmentDaoMyBatisImplTest {

	@Autowired
	private DepartmentDaoMyBatisImpl dao;

	private List<Department> allDepartmentsOnly = Arrays.asList(
		new Department(10, "ACCOUNTING", "NEW YORK"),
		new Department(20, "RESEARCH", "DALLAS"),
		new Department(30, "SALES", "CHICAGO"),
		new Department(40, "OPERATIONS", "BOSTON")
	);

	@Test
	void testGetAllDepartments() {
		// ACT
		List<Department> departments = dao.getAllDepartments();

		// ASSERT
		// getAllDepartments() doesn't select Employees, so all 
		// Departments' employees lists are null
		assertEquals(allDepartmentsOnly, departments);
	}

	@Test
	void testGetAllDepartmentsAndEmployees() {
		// ARRANGE
		Employee emp7782 = new Employee(7782, "CLARK", "MANAGER", 7839, LocalDate.of(1981, 6, 9), 2450.0, 0.0, 10);
		Employee emp7839 = new Employee(7839, "KING", "PRESIDENT", 0, LocalDate.of(1981, 11, 17), 5000.0, 0.0, 10);
		Employee emp7934 = new Employee(7934, "MILLER", "CLERK", 7782, LocalDate.of(1982, 1, 23), 1300.0, 0.0, 10);

		Department dept10 = new Department(10, "ACCOUNTING", "NEW YORK", 
									  Arrays.asList(emp7782, emp7839, emp7934));
		Department dept40 = new Department(40, "OPERATIONS", "BOSTON", Arrays.asList());
		
		// ACT
		List<Department> departments = dao.getAllDepartmentsAndEmployees();
		
		// ASSERT
		assertEquals(4, departments.size());
		assertTrue(departments.contains(dept10));  // verifies Department properties, including Employees list
		assertTrue(departments.contains(dept40));
	}
}
