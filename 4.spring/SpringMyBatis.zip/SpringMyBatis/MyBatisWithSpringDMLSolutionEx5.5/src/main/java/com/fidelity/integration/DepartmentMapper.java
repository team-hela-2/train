package com.fidelity.integration;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.apache.ibatis.mapping.StatementType;

import com.fidelity.business.Department;

public interface DepartmentMapper {
	@Select("SELECT deptno AS id, dname AS name, loc AS location " + 
			"FROM   dept\r\n" + 
			"ORDER BY id")
	List<Department> getAllDepartments();
	
	@Select("SELECT d.deptno AS id, d.dname, d.loc, e.empno, e.ename, e.job, e.mgr, " + 
			"	   e.hiredate, e.sal, e.comm, e.deptno " + 
			"FROM   dept d " + 
			"LEFT OUTER JOIN emp e " + 
			"ON     d.deptno = e.deptno " + 
			"ORDER BY id, e.empno")
	@ResultMap("com.fidelity.integration.DepartmentMapper.DepartmentAndEmployees")
	List<Department> getAllDepartmentsAndEmployees();
	
	@Insert("INSERT INTO dept (deptno, dname, loc) " + 
			"VALUES (#{id}, #{name}, #{location})")
	int insertDepartment(Department department);

	@Update("UPDATE dept " + 
			"SET    dname = #{name}, loc = #{location} " + 
			"WHERE  deptno = #{id}")
	int updateDepartment(Department department);
	
	// Not asked for, but allows us to demonstrate the constraint violation
	@Delete("DELETE FROM dept WHERE deptno = #{id}")
	int deleteDepartment(int deptId);
	
	@Update("{ CALL proc_reassign_emp_delete_dept(#{deptDelete, mode=IN, jdbcType=INTEGER}, #{deptAssign, mode=IN, jdbcType=INTEGER}) }")
	@Options(statementType = StatementType.CALLABLE)
	void reassignEmployeesDeleteDepartment(@Param("deptDelete") int deptDelete, @Param("deptAssign") int deptAssign);

}
