package com.fidelity.foo;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class FooFactoryTest {
	String message;
	
	@BeforeEach
	void setUp() {
		message = "Hello World ";
	}

	@Test
	void testCreateFoo() throws Exception {
		String expected = message;
		Foo foo = FooFactory.createFoo(message);
		String actual = foo.getMessage();
		
		assertEquals(expected, actual);
	}

	@Test
	void testInvokeBar() throws Exception {
		String expected = message;
		String actual = FooFactory.invokeBar(message);
		
		assertEquals(expected, actual);
	}

}
