package com.fidelity.mapexample;

public class Employee {
	int id;
	String name;

	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

}
