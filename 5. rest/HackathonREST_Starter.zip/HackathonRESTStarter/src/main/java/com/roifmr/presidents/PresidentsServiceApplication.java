package com.roifmr.presidents;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PresidentsServiceApplication {
	
	public static void main(String[] args) {
		SpringApplication.run(PresidentsServiceApplication.class, args);
	}

}
