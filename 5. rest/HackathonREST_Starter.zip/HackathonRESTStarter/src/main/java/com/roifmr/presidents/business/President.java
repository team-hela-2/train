package com.roifmr.presidents.business;

public class President {
	private int id;
	private String firstName;
	private String lastName;
	private int firstYear;
	private int lastYear;
	private String image;
	private String biography;

}
