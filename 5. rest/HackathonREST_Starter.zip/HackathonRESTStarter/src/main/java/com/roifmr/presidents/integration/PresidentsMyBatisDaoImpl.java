package com.roifmr.presidents.integration;

import org.springframework.stereotype.Repository;

@Repository
public class PresidentsMyBatisDaoImpl {

}
