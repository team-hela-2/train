package com.roifmr.presidents.restservices;

import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;

@WebMvcTest(PresidentsService.class)
public class PresidentsServiceWebLayerTest {

}
