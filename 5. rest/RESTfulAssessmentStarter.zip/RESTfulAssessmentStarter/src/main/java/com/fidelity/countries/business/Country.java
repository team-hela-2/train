package com.fidelity.countries.business;

public class Country {
	// DO NOT CHANGE THESE FIELD NAMES
	private int id;
	private String name;
	private String region;
	private double population;

}
