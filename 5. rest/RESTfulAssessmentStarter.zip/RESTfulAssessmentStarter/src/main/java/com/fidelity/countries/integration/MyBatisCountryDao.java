package com.fidelity.countries.integration;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.fidelity.countries.business.Country;
import com.fidelity.countries.integration.mapper.CountriesMapper;

@Repository
public class MyBatisCountryDao {
	
}
