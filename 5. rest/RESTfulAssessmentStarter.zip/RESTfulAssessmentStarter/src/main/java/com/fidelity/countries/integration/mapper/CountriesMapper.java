package com.fidelity.countries.integration.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.fidelity.countries.business.Country;

@Mapper
public interface CountriesMapper {
	List<String> findAllNames();
	Country findCountry(int id);
}
