-- Oracle schema definition for the countries table

-- drop the countries database table

drop table countries;

create table countries (
	country_id integer, 
	name varchar(45), 
	region varchar(45), 
	population number, 
	area number, 
	population_density number, 
	per_capita_gdp number, 
	phones_per_thousand number
);
