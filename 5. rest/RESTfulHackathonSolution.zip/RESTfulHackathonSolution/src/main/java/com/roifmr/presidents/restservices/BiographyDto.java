package com.roifmr.presidents.restservices;

/**
 * BiographyDto is a data transfer object (DTO) that wraps a President's biography.
 * A web service method can return a BiographyDto instance to ensure that the response
 * body contains well-formed JSON:
 *     {"bio": "On April 30, 1789, ..."}
 */
public class BiographyDto {
	private String bio;
	
	public BiographyDto() {}
	
	public BiographyDto(String bio) {
		this.bio = bio;
	}
	
	public String getBio() {
		return bio;
	}
	
	public void setBio(String bio) {
		this.bio = bio;
	}
}
