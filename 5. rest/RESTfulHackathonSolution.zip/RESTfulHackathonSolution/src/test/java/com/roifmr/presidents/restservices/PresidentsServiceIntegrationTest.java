package com.roifmr.presidents.restservices;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.jdbc.JdbcTestUtils;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import com.roifmr.presidents.business.President;

@SpringBootTest
@Transactional
public class PresidentsServiceIntegrationTest {

	@Autowired
	private PresidentsService service;

	@Autowired
	private JdbcTemplate jdbcTemplate;  // for executing SQL queries

	// Initialize a few Presidents for expected values in test cases
	private President president1 = new President(1,"George","Washington",1789,1797,"georgewashington.jpg",
			"On April 30, 1789, George Washington, standing on the balcony of Federal Hall on Wall Street "
			+ "in New York, took his oath of office as the first President of the United States. "
			+ "\"As the first of every thing, in our situation will serve to establish a Precedent,\" "
			+ "he wrote James Madison, \"it is devoutly wished on my part, that these precedents may be "
			+ "fixed on true principles.\" Born in 1732 into a Virginia planter family, he learned the "
			+ "morals, manners, and body of knowledge requisite for an 18th century Virginia gentleman.");
	
	private President president10 = new President(10,"John","Tyler",1841,1845,"johntyler.jpg",
			"Dubbed \"His Accidency\" by his detractors, John Tyler was the first Vice President to be "
			+ "elevated to the office of President by the death of his predecessor. Born in Virginia in "
			+ "1790, he was raised believing that the Constitution must be strictly construed. He never "
			+ "wavered from this conviction. He attended the College of William and Mary and studied law.");
	
	@Test
	void testQueryForAllPresidentsSuccess() {
		int expectedSize = JdbcTestUtils.countRowsInTable(jdbcTemplate, "presidents");
		
		ResponseEntity<List<President>> responseStatus = service.queryForAllPresidents();
		
		assertThat(responseStatus.getStatusCode(), is(equalTo(HttpStatus.OK)));
		List<President> presidentList = responseStatus.getBody();
		assertThat(presidentList.size(), is(equalTo(expectedSize)));
		for (President president: presidentList) {
			assertThat(president, is(notNullValue()));
		}
		assertThat(presidentList.get(0), is(equalTo(president1)));
		assertThat(presidentList.get(9), is(equalTo(president10)));
	}
	
	@Test
	void testQueryForAllPresidentsEmptyTable() {
		JdbcTestUtils.deleteFromTables(jdbcTemplate, "presidents");
		
		ResponseEntity<List<President>> responseStatus = service.queryForAllPresidents();
		
		assertThat(responseStatus.getStatusCode(), is(equalTo(HttpStatus.NO_CONTENT)));
		List<President> presidentList = responseStatus.getBody();
		assertThat(presidentList, is(nullValue()));
	}

	// HyperSQL does not support rollback of DROP TABLE, so we can't
	// easily force a database error in the integration test.

	@Test
	void testQueryForPresidentBiography() {
		ResponseEntity<BiographyDto> response = service.queryForPresidentBiography(1);
		
		assertThat(response.getBody().getBio(), is(equalTo(president1.getBiography())));
	}
	
	@Test
	void testQueryForPresidentBiographyNotFound() {
		ResponseEntity<BiographyDto> response = service.queryForPresidentBiography(99);
		
		assertThat(response.getStatusCode(), is(equalTo(HttpStatus.NO_CONTENT)));
		assertThat(response.getBody(), is(nullValue()));
	}
	
	@Test
	void testQueryForPresidentBiographyInvalidId() {
		ResponseStatusException ex = assertThrows(ResponseStatusException.class, 
			() -> service.queryForPresidentBiography(0)
		);
			
		assertThat(ex.getStatus(), is(equalTo(HttpStatus.BAD_REQUEST)));
	}
}
