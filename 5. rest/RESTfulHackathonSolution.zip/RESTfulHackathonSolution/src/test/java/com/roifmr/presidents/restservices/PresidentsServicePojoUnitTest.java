package com.roifmr.presidents.restservices;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.server.ServerErrorException;
import org.springframework.web.server.ServerWebInputException;

import com.roifmr.presidents.business.President;
import com.roifmr.presidents.integration.PresidentsDao;

/**
 * PresidentsServicePojoUnitTest defines unit tests for PresidentsService.
 */
public class PresidentsServicePojoUnitTest {
	@Mock
	private PresidentsDao mockDao;
	@Mock
	private Logger mockLogger;
	
	@InjectMocks
	private PresidentsService service;
	
	@BeforeEach
	void setUp() throws Exception {
		service = new PresidentsService();
		MockitoAnnotations.openMocks(this);  // initMocks() is deprecated
	}
	
	private static final List<President> expectedPresidents = Arrays.asList(
		new President(1, "George", "Washington", 1789, 1797, "georgewashington.jpg", "Chopped down a cherry tree"), 
		new President(2, "John", "Adams", 1797, 1801, "johnadams.jpg", "Learned and thoughtful")
	);
	
	@Test
	public void testGetAllPresidentsSuccess() throws Exception {
		when(mockDao.queryForAllPresidents())
			.thenReturn(expectedPresidents);
		
		ResponseEntity<List<President>> responseStatus = service.queryForAllPresidents();
		
		HttpStatus statusCode = responseStatus.getStatusCode();
		assertThat(statusCode, is(equalTo(HttpStatus.OK)));
		List<President> actualPresidents = responseStatus.getBody();
		assertThat(actualPresidents, is(equalTo(expectedPresidents)));
	}

	@Test
	public void testGetAllPresidentsDaoReturnsEmptyList() throws Exception {
		when(mockDao.queryForAllPresidents())
			.thenReturn(new ArrayList<President>());
		
		ResponseEntity<List<President>> responseStatus = service.queryForAllPresidents();
		
		HttpStatus statusCode = responseStatus.getStatusCode();
		assertThat(statusCode, is(equalTo(HttpStatus.NO_CONTENT)));
		List<President> actualPresidents = responseStatus.getBody();
		assertThat(actualPresidents, is(nullValue()));
	}

	@Test
	public void testGetAllPresidentsDaoReturnsNull() throws Exception {
		when(mockDao.queryForAllPresidents())
			.thenReturn(null);
		
		ResponseEntity<List<President>> responseStatus = service.queryForAllPresidents();
		
		HttpStatus statusCode = responseStatus.getStatusCode();
		assertThat(statusCode, is(equalTo(HttpStatus.NO_CONTENT)));
		List<President> actualPresidents = responseStatus.getBody();
		assertThat(actualPresidents, is(nullValue()));
	}

	@Test
	public void testGetAllPresidentsDaoThrowsException() throws Exception {
		when(mockDao.queryForAllPresidents())
			.thenThrow(new RuntimeException("mock exception"));
		
		ServerErrorException ex = assertThrows(ServerErrorException.class, 
			() -> service.queryForAllPresidents()
		);
			
		assertThat(ex.getStatus(), is(equalTo(HttpStatus.INTERNAL_SERVER_ERROR)));
	}

	@Test
	public void testQueryForPresidentBiographySuccess() throws Exception {
		String expectedBio = expectedPresidents.get(0).getBiography();
		when(mockDao.queryForPresidentBiography(anyInt()))
			.thenReturn(expectedBio);
				
		ResponseEntity<BiographyDto> response = service.queryForPresidentBiography(1);

		assertThat(response.getStatusCode(), is(equalTo(HttpStatus.OK)));
		assertThat(response.getBody().getBio(), is(equalTo(expectedBio)));
	}
	
	@Test
	public void testQueryForPresidentBiographyNonExistantId() throws Exception {
		when(mockDao.queryForPresidentBiography(anyInt()))
			.thenReturn(null);
				
		ResponseEntity<BiographyDto> response = service.queryForPresidentBiography(99);
		
		assertThat(response.getStatusCode(), is(equalTo(HttpStatus.NO_CONTENT)));
		assertThat(response.getBody(), is(nullValue()));
	}
	
	@Test
	public void testQueryForPresidentBiographyInvalidId() throws Exception {
		ServerWebInputException ex = assertThrows(ServerWebInputException.class, 
			() -> service.queryForPresidentBiography(0)
		);
			
		assertThat(ex.getStatus(), is(equalTo(HttpStatus.BAD_REQUEST)));
	}
	
	@Test
	public void testQueryForPresidentBiographyDaoException() throws Exception {
		when(mockDao.queryForPresidentBiography(anyInt()))
			.thenThrow(new RuntimeException("mock exception"));
		
		ServerErrorException ex = assertThrows(ServerErrorException.class, 
			() -> service.queryForPresidentBiography(1)
		);
			
		assertThat(ex.getStatus(), is(equalTo(HttpStatus.INTERNAL_SERVER_ERROR)));
	}
}
