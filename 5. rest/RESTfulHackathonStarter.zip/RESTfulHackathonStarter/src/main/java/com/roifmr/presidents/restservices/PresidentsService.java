package com.roifmr.presidents.restservices;

public class PresidentsService {

}
