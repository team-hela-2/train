package com.fidelity.application;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InjectionPoint;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Scope;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;

@RestController
@SpringBootApplication
public class BookstoreApplication {

  @RequestMapping(value = "/recommended")
  public String readingList(){
    return "Spring in Action (Manning), Cloud Native Java (O'Reilly), Learning Spring Boot (Packt)";
  }

  public static void main(String[] args) {
    SpringApplication.run(BookstoreApplication.class, args);
  }

  /**
   * This method allows Loggers to be autowired in other classes:
   *    @Autowired private Logger logger;
   */
  @Bean
  @Scope("prototype")
  public Logger createLogger(InjectionPoint ip) {
      Class<?> classThatWantsALogger = ip.getField().getDeclaringClass();
      return LoggerFactory.getLogger(classThatWantsALogger);
  }
}
