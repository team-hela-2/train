package com.fidelity.lambda;

public class Greetings {
	private String greeting;

	public String getGreeting() {
		return greeting;
	}

	public void setGreeting(String greeting) {
		this.greeting = greeting;
	}

	public Greetings(String greeting) {
		super();
		this.greeting = greeting;
	}
	
	public Greetings() {}
}
