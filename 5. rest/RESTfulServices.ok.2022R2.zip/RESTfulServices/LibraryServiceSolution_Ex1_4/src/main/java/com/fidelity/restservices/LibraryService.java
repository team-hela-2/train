package com.fidelity.restservices;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.fidelity.business.Book;
import com.fidelity.business.BookList;
import com.fidelity.integration.LibraryDao;


@RestController
@RequestMapping("/library")
public class LibraryService {
	@Autowired
	private LibraryDao dao;
	
	public LibraryService() {
	}

	@RequestMapping(value = "/books", method = RequestMethod.GET,
			produces = { "application/json", "application/xml" })
	public ResponseEntity<BookList<Book>> getBooks() {
		BookList<Book> booksList = null;
		
		try {
			List<Book> books = dao.getBooks();
			
			if (books.isEmpty()) {
				return  ResponseEntity.status(HttpStatus.NO_CONTENT).body(booksList);
			}
			
			booksList = new BookList<Book>(dao.getBooks());
		} catch(RuntimeException e) {
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to communicate with the library", e);
		}
		
		return  ResponseEntity.status(HttpStatus.OK).body(booksList);
	}

	@RequestMapping(value = "/{id}", method = RequestMethod.GET,
			produces = { "application/json", "application/xml" })
	public ResponseEntity<Book> getBookById(@PathVariable String id) {
		Book book = null;
		
		try {
			book = dao.getBookByIsbn(id);
		} catch (RuntimeException e) {
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Unable to communicate with the library", e);
		}
		
		if (book == null) {
			return  ResponseEntity.status(HttpStatus.NO_CONTENT).body(book);
		}
		
		return ResponseEntity.status(HttpStatus.OK).body(book);
	}
}
