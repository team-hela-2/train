package com.fidelity.MessageServer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class MessageServerApplicationTests {

	@Test
	public void contextLoads() {
	}

}
