-- Inserting data into the Products warehouse

-- WIDGETS
INSERT INTO WIDGETS VALUES (1, 'Extremely Low Impact Widget', 12.99, 2, 3);
INSERT INTO WIDGETS VALUES (2, 'Just Average Medium Impact Widget', 42.99, 5, 5);
INSERT INTO WIDGETS VALUES (3, 'Tim Taylor Ridiculously High Impact Widget', 89.99, 10, 8);

-- GADGETS
INSERT INTO GADGETS VALUES (1, 'Three Cylinder Gadget', 19.99, 2); 
INSERT INTO GADGETS VALUES (2, 'Five Cylinder Gadget', 29.99, 4); 
INSERT INTO GADGETS VALUES (3, 'Nine Cylinder Gadget', 49.99, 8); 


-- Commit
commit;