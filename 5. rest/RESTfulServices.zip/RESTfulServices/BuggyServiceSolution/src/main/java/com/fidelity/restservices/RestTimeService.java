package com.fidelity.restservices;


import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.fidelity.business.TimeZoneException;
import com.fidelity.business.TimeZoneInfo;
import com.fidelity.business.TimeZoneService;


@RestController
@RequestMapping("/time")
public class RestTimeService {
	private TimeZoneService tzservice;

	public RestTimeService() {
		tzservice = new TimeZoneService();
	}

	@RequestMapping(value = "/current", method = RequestMethod.GET,
			produces = { "application/json" })
	public TimeZoneInfo getTime() {
		TimeZoneInfo tz = null;

		try {
			tz = tzservice.getTime();
		} catch (RuntimeException e) {
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Server side error", e);
		}

		return tz;
	}

	@RequestMapping(value = "/zone/{timezone}", method = RequestMethod.GET,
			produces = { "application/json" })
	public TimeZoneInfo getTimeInJson(@PathVariable String timezone) throws TimeZoneException {
		TimeZoneInfo tz = null;
		
		try { 
			tz = tzservice.getTimeForTimezone(timezone);
		}catch (RuntimeException e) {
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Server side error", e);
		}

		if (tz == null) {
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid timezone: " + timezone);
		}
		return tz;
	}
}
