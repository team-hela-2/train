package com.fidelity.integration;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.fidelity.business.Ship;
import com.fidelity.integration.mapper.ShipMapper;

@Repository("ShipDaoMyBatis")
public class ShipDaoMyBatisImpl implements ShipDao {
	@Autowired
	private ShipMapper mapper;
	
	@Override
	public List<Ship> queryAllShips() {
		List<Ship> ships = null;
		
		ships = mapper.getAllShips();
		
		return ships;
	}
}
