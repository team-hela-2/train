package com.fidelity.business;

import java.util.ArrayList;
import java.util.List;


public class BookList<T> {

	private List<T> bookList;

	public BookList() {
		bookList = new ArrayList<>();
	}

	public BookList(List<T> list) {
		bookList = list;
	}

	
	public List<T> getItems() {
		return bookList;
	}
}
