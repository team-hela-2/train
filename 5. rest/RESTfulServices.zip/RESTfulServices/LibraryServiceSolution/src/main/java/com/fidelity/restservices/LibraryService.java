package com.fidelity.restservices;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fidelity.business.Book;
import com.fidelity.business.BookList;
import com.fidelity.integration.LibraryDao;


@RestController
@RequestMapping("/library")
public class LibraryService {
	@Autowired
	private LibraryDao dao;
	
	public LibraryService() {
	}

	@RequestMapping(value = "/books", method = RequestMethod.GET,
			produces = { "application/json", "application/xml" })
	public BookList<Book> getBooks() {
		BookList<Book> books = null;
		
		books = new BookList<Book>(dao.getBooks());
		
		return books;
	}

	@RequestMapping(value = "/{id}", method = RequestMethod.GET,
			produces = { "application/json", "application/xml" })
	public Book getBookById(@PathVariable String id) {
		Book book = null;
		
		book = dao.getBookByIsbn(id);
		
		return book;
	}
}
