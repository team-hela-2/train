package com.fidelity.controller;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.fidelity.domain.MessageServiceResponse;

@RestController
public class MessageRestController {
	@RequestMapping(value="/message", method = RequestMethod.GET, 
			produces = MediaType.APPLICATION_JSON_VALUE)
	public MessageServiceResponse getMessage() {
		String message = "Very important message: the answer is 42";
		MessageServiceResponse response = new MessageServiceResponse(message);
		
		return response;	
	}
}
