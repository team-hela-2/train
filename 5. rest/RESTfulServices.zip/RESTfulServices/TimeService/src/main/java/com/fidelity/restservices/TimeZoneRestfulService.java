package com.fidelity.restservices;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.fidelity.business.TimeZoneBusinessService;
import com.fidelity.business.TimeZoneInfo;

/**
 * TimeZoneRestfulService is a RESTful web service that reports the current time
 * for the local time zone, or for a specified time zone.
 * 
 * @author ROI Instructor
 *
 */
@RestController
@RequestMapping("/time")
public class TimeZoneRestfulService {
	@Autowired
	private TimeZoneBusinessService tzservice;

	/**
	 * getCurrentTime() returns the current time for the time zone where the server is located
	 * 
	 * @return  TimeZoneInfo with the current time for the local time zone
	 */
	@RequestMapping(value = "/current", method = RequestMethod.GET, produces = { "application/json" })
	public TimeZoneInfo getCurrentTime() {
		TimeZoneInfo tzinfo = null;

		try {
			tzinfo = tzservice.getTime();
		} catch (RuntimeException e) {
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Server side error", e);
		}

		return tzinfo;
	}

	/**
	 * getTimeForZoneInRequest() returns the time for the specified time zone
	 * The time zone is specified  with a request parameter
	 * 
	 * For example: http://localhost:8080/time?timezone=America/New_York
	 * 
	 * @param timezone - the specified timezone
	 * @return TimeZoneInfo with the current time for the local timezone
	 */
	@RequestMapping(method = RequestMethod.GET, produces = { "application/json" }, params = { "timezone" })
	public TimeZoneInfo getTimeForZoneInRequest(@RequestParam String timezone) {
		TimeZoneInfo tz = null;

		try {
			tz = tzservice.getTimeForTimezone(timezone);
		} catch (RuntimeException e) {
			// Report a problem on the server
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Server side error", e);
		}

		if (tz == null) {
			// Blame the user for passing an invalid timezone
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid timezone: " + timezone);
		}
		return tz;
	}

	/**
	 * getTimeForZoneInRequest() returns the time for the specified timezone
	 * The timezone is specified  with a path parameter
	 * For example: http://localhost:8080/time/EST
	 * 
	 * @param timezone - the specified timezone
	 * @return TimeZoneInfo with the current time for the local timezone
	 */
	@RequestMapping(value="/{timezone}", method = RequestMethod.GET, produces = { "application/json" })
	public TimeZoneInfo getTimeForZoneInPath(@PathVariable String timezone) {
		TimeZoneInfo tz = null;

		try {
			tz = tzservice.getTimeForTimezone(timezone);
		} catch (RuntimeException e) {
			// Report a problem on the server
			throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Server side error", e);
		}

		if (tz == null) {
			// Blame the user for passing an invalid timezone
			throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid timezone: " + timezone);
		}
		return tz;
	}

}
