package com.fidelity.restservices;

import java.util.*;

import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

import static org.mockito.Mockito.*;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.fidelity.business.*;
import com.fidelity.business.service.WarehouseBusinessService;
import com.fidelity.integration.WarehouseDao;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.server.ResponseStatusException;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.nullValue;

/**
 * JUnit tests for WarehouseService using Mockito for managing mock objects.
 * 
 * Note that this is a pure unit test, not an integration test: Spring is not 
 * involved in this test at all. We are testing the controller class as a POJO
 * in complete isolation, so we don't want Spring configuration issues to 
 * cause these tests to fail. The other test classes in this package will do 
 * integration testing to verify the Spring configuration. 
 * 
 * In general, a pure unit test for RESTful controllers might be redundant,
 * because you'll test controllers thoroughly using @MockWebMvc (as in 
 * WarehouseServiceWebMockTest.java) and as a deployed service
 * (as in WarehouseServiceTestRestTemplateTest.java). But the techniques
 * shown below are useful for unit testing any class that has dependencies,
 * not just RESTful controllers.
 *
 * Spring Boot includes Mockito, but if you are running unit tests
 * without Spring Boot, you need to add Mockito dependencies to pom.xml:
 * 		<dependency>
 *			<groupId>org.mockito</groupId>
 *			<artifactId>mockito-core</artifactId>
 *			<version>3.3.3</version>
 *			<scope>test</scope>
 *		</dependency>
 *		<dependency>
 *			<groupId>org.mockito</groupId>
 *			<artifactId>mockito-junit-jupiter</artifactId>
 *			<version>3.3.3</version>
 *			<scope>test</scope>
 *		</dependency>
 *
 * You also may need to change the version of the junit-platform-surefire-provider dependency:
 *		<dependency>
 *			<groupId>org.junit.platform</groupId>
 *			<artifactId>junit-platform-surefire-provider</artifactId>
 *			<version>1.3.2</version>
 *		</dependency>
 * 
 * @author ROI Instructor
 */

public class WarehouseServiceMockitoTest {
	// Our WarehouseService has a dependency on the WarehouseDao class.
	// Because this is a pure unit test, we create a mock to replace the WarehouseDao.
	@Mock
	private WarehouseDao mockDao;

	@Mock
	private WarehouseBusinessService mockBusinessService;
	
	// @InjectMocks tells Mockito to inject the mock WarehouseDAO into the 
    // service instance. If we didn't create the service instance in the setUp()
	// method, Mockito would create it for us.
	@InjectMocks 
	private WarehouseService service;
	
	@BeforeEach
	public void setUp() {
		service = new WarehouseService(); // pass constructor args if needed
		
		MockitoAnnotations.openMocks(this); // required initialize all mocks
	}

	@Test
	public void testQueryForAllGadgets_ListLength2_ReturnsStatus200() {
		
		//--------- Arrange: set up to call the method being tested -----------
		
		// Initialize the list of Gadgets that will be returned by the mock DAO
		List<Gadget> gadgets = Arrays.asList(
				new Gadget(1, "Two Cylinder Gadget", 19.99, 2),
				new Gadget(1, "Four Cylinder Gadget", 29.99, 3));
		
		// Configure the mock DAO to return the list of Gadgets when 
		// its getAllGadgets() method is called by the WarehouseService
		when( mockDao.getAllGadgets() )
		             .thenReturn(gadgets);

		//--------- Act: call the method being tested -------------------------
		
		// call a service method with a plain Java call: no HTTP request is created
		ResponseEntity<List<Gadget>> response = service.queryForAllGadgets();
		
		//--------- Assert: verify the result ---------------------------------

		// Verify correct HTTP status
		assertThat(response.getStatusCode(), equalTo(HttpStatus.OK));
		
		// Verify response body content
		assertThat(response.getBody(), equalTo(gadgets));
	}
	
	@Test
	public void testQueryForAllGadgets_EmptyList_ReturnsStatus204() {
		// Configure the mock DAO to return an empty list when
		// its getAllGadgets() method is called
		when( mockDao.getAllGadgets() )
		             .thenReturn(new ArrayList<Gadget>());

		ResponseEntity<List<Gadget>> response = service.queryForAllGadgets();
		
		assertThat(response.getStatusCode(), equalTo(HttpStatus.NO_CONTENT));
		assertThat(response.getBody(), is(nullValue()));
	}

	@Test
	public void testQueryForAllGadgets_DaoThrowsException_ReturnsStatus500() {
		// Configure the mock DAO to throw an unchecked exception when
		// its getAllGadgets() method is called
		when( mockDao.getAllGadgets() )
		             .thenThrow(new IllegalStateException());

		ResponseStatusException ex = assertThrows(ResponseStatusException.class, () ->
			service.queryForAllGadgets()
		);
		
		assertThat(ex.getStatus(), equalTo(HttpStatus.INTERNAL_SERVER_ERROR));
	}
	
	@Test
	public void testQueryForAllWidgets_ListLength2_ReturnsStatus200() {
		List<Widget> widgets = Arrays.asList(
			    new Widget(1, "Low Impact Widget", 12.99, 2, 3),
			    new Widget(2, "High Impact Widget", 15.99, 4, 5));
		
		when( mockBusinessService.findAllWidgets() )
		                         .thenReturn(widgets);

		ResponseEntity<List<Widget>> response = service.queryForAllWidgets();
		
		assertThat(response.getStatusCode(), equalTo(HttpStatus.OK));
		assertThat(response.getBody(), equalTo(widgets));
	}
	
	@Test
	public void testQueryForAllWidgets_EmptyList_ReturnsStatus204() {
		// Configure the mock DAO to return an empty list
		when( mockBusinessService.findAllWidgets() )
		             .thenReturn(new ArrayList<Widget>());

		ResponseEntity<List<Widget>> response = service.queryForAllWidgets();
		
		assertThat(response.getStatusCode(), equalTo(HttpStatus.NO_CONTENT));
		assertThat(response.getBody(), is(nullValue()));
	}

	@Test
	public void testQueryForAllWidgets_DaoThrowsException_ReturnsStatus500() {
		// Configure the mock DAO to throw an unchecked exception
		when( mockBusinessService.findAllWidgets() )
		             .thenThrow(new IllegalStateException());

		ResponseStatusException ex = assertThrows(ResponseStatusException.class, () ->
			service.queryForAllWidgets()
		);
	
		assertThat(ex.getStatus(), equalTo(HttpStatus.INTERNAL_SERVER_ERROR));
	}
}
