package com.fidelity.server.main;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.fidelity.configuration.WarehouseSpringConfiguration;
import com.fidelity.restservices.WarehouseService;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(locations = "classpath:applicationContext.xml")
@SpringBootTest
public class WarehouseSpringBootServiceApplicationTests {
	
	@Autowired
	private WarehouseSpringConfiguration config;
	
	@Autowired
	private WarehouseService service;
	
	@Test
	public void contextLoads() {
		assertNotNull(config);
	}
	
	@Test
	public void serviceLoads() {
		assertNotNull(service);
	}

}
