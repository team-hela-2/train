package com.fidelity.security;

import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableResourceServer;
import org.springframework.security.oauth2.config.annotation.web.configuration.ResourceServerConfigurerAdapter;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@EnableResourceServer
@RestController
public class ResourceServerConfiguration extends ResourceServerConfigurerAdapter {
	@RequestMapping("/admin")
	public Answer admin() {
		Answer theAnswer = new Answer("Do you have the right to make this request?", "This is for administrators only.");
		return theAnswer;
	}

	@RequestMapping("/public")
	public Answer welcome() {
		Answer theAnswer = new Answer("What would you like to ask?", "This is the welcome message.");
		return theAnswer;
	}

	@RequestMapping("/private")
	public Answer question() {
		Answer theAnswer = new Answer("What is the answer to Life, the Universe and Everything?", "42, but of course.");
		return theAnswer;
	}

	@Override
	public void configure(HttpSecurity http) throws Exception {
		http.authorizeRequests()
			.antMatchers("/oauth/token", "/oauth/authorize**", "/public")
			.permitAll();
		
		http.requestMatchers()
			.antMatchers("/public").and().anonymous()
		    .and()
			.requestMatchers()
			.antMatchers("/admin").and().authorizeRequests()
			.antMatchers("/admin").access("hasRole('ADMIN')");
	}
}
