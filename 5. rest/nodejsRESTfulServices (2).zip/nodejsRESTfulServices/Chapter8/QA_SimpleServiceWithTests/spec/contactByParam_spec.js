const request = require("request");

const base_url = 'http://localhost:8081/';
const contacts_url = base_url + 'contacts?lastname=Smith';

describe("First Node Test Server", () => {
    describe("GET /contacts?lastname=<name>", () => {
        it("returns Smith", (done) => {
            request.get(contacts_url, (error, response, body) => {
                expect(body).toBeTruthy();
                expect(body).toContain("Smith");
                done();
            });
        });
        // when searching for unknow contact return 404
        it("returns 404", (done) => {
            // TODO: Try to get contact with name Washington
            // expect 404 for response.statuscode
            expect(true).toBe(false);
            done();
        });
        // when using wrong search key word return 500
        it("returns 500 when searching for cell phone", (done) => {
            // TODO: Try to use cellphone as argument and expect 
            // 500 for response.statuscode
            expect(true).toBe(false);
            done();
            // inspect code in index.js to understand behavior
        });
    });
    describe("GET /contact/lastname/:lastname", () => {
        // TODO: use path parameter option with lastname Smith to load contact
        it("returns Smith", function (done) {
            expect(true).toBe(false);
            done();
        });
        // when searching for unknow contact return 404
        it("returns 404 with unknow name", (done) => {
            request.get(base_url + 'contact/lastname/Washington', 
                (error, response, body) => {
                    expect(response.statusCode).toBe(404);
                    done();
            });
        });
        // when searching with unknown path return 404
        it("returns 404 with unknow path", (done) => {
            // TODO: use unknow path parameter to access contact
            // expect 404 as return value
            expect(true).toBe(false);
            done();
        });
    });
});