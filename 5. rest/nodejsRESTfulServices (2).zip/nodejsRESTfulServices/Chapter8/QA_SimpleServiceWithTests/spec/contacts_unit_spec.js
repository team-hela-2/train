let request = require("request");
let contacts = require("../modules/contacts");

describe("Unit tests on contacts module", () => {
    describe("load all contacts", () => {
        //positive test to load all contacts
        it("have two elements", () => {
            let results = contacts.list();
            expect(results.result.length).toBe(2);
        });
        
    });
    describe("load specific contacts", () => {
        //positive test to load contact by last name
        it("with last name Smith", () => {
            let results = contacts.query_by_arg("lastname", "Smith");
            expect(results.firstname).toBe("Joe");
        });
        //positive test to load contact by first name
        it("with first name John", () => {
            // TODO: test loading with first name "John"
            expect(true).toBe(false);
        });
        //exception test to load contact by cell phone (argument does not exists)
        it("with cell phone number +00000", () => {
            // TODO:Add exception test for trying to load contact by cellphone number
            // use: toThrow("Unknow parameter cellphone");
            // implement necessary code to make it pass
            expect(true).toBe(false);
        });
        //negative test to load contact by cell phone (value does not exists)
        it("with first name Max", () => {
            // TODO: try to load contact with name Max
            // test for return value null
            expect(true).toBe(false);
        });
       
    });

});
